from pathlib import Path
import json, re
import numpy as np
from scipy.io.wavfile import write
from scipy.signal import resample_poly
from scipy.spatial.distance import cdist
from piper import PiperVoice, SynthesisConfig

root = Path(__file__).resolve().parent
out = root.parent / 'output'
voice = PiperVoice.load(root / 'en_GB-alan-medium.onnx')
sentences = (root / 'VOICEOVER_EN.txt').read_text().strip().split('\n\n')
groups = [b.splitlines()[2] for b in (root / 'EPISODE_002_DRAFT.srt').read_text().strip().split('\n\n')]
sr = 22050
hop = 220
samples_per_frame = 735
rng = np.random.default_rng(12)

def synth(text, scale):
    chunks = []
    for chunk in voice.synthesize(text, SynthesisConfig(length_scale=scale, noise_scale=.48, noise_w_scale=.65)):
        x = chunk.audio_float_array
        nz = np.flatnonzero(abs(x) > .014)
        chunks.append(x[max(0,nz[0]-450):nz[-1]+500])
    return np.concatenate([np.concatenate((x,np.zeros(2200))) for x in chunks])[:-2200]

def features(x):
    windows = np.lib.stride_tricks.sliding_window_view(np.pad(x, (256,255)), 512)[::hop]
    spec = abs(np.fft.rfft(windows*np.hanning(512)))
    bands = np.unique(np.geomspace(2,180,29).astype(int))
    z = np.stack([np.log(.03+spec[:,a:b].mean(1)) for a,b in zip(bands,bands[1:])],1)
    return (z-z.mean(axis=1,keepdims=True))/(z.std(axis=1,keepdims=True)+.1)

def align(reference, target, boundaries):
    distances = cdist(features(reference), features(target), 'sqeuclidean')
    rows, cols = distances.shape
    score = np.full((rows+1, cols+1), np.inf)
    score[0,0] = 0
    path = np.zeros((rows,cols), np.uint8)
    for i in range(rows):
        for j in range(cols):
            options = (score[i,j], score[i,j+1]+4, score[i+1,j]+4)
            choice = min(range(3),key=options.__getitem__)
            score[i+1,j+1] = distances[i,j] + options[choice]
            path[i,j] = choice
    i,j = rows-1,cols-1
    mapping = {}
    while i>=0 and j>=0:
        mapping[i] = j
        choice = path[i,j]
        i -= choice != 2
        j -= choice != 1
    return [mapping.get(min(rows-1,round(b/hop)),cols-1)*hop for b in boundaries]

scale = .97
takes = [synth(s,scale) for s in sentences]
measured = sum(map(len,takes))/sr
print('Speech duration before holds:', measured, flush=True)
if not 44 <= measured <= 49:
    scale *= 46.8/measured
    takes = [synth(s,scale) for s in sentences]
holds = [15,12,11,10,11,14,12,21,14,16,28]
mix,shots,captions = [],[],[]
cursor = 0
for k, (paragraph, take) in enumerate(zip(sentences,takes)):
    parts = []
    while ' '.join(parts) != paragraph:
        parts.append(groups.pop(0))
    guide = [synth(g,scale) for g in parts]
    begins = [0] + align(np.concatenate(guide),take,np.cumsum([len(g) for g in guide])[:-1])
    lead = 3
    speech_frames = int(np.ceil(len(take)/samples_per_frame))
    shot_frames = lead + speech_frames + holds[k]
    frame_audio = np.zeros(shot_frames*samples_per_frame,dtype=np.float32)
    frame_audio[lead*samples_per_frame:lead*samples_per_frame+len(take)] = take*.72
    shots.append([cursor,cursor+shot_frames])
    cuts = [cursor+lead+round(b/samples_per_frame) for b in begins]
    cuts += [cursor+lead+speech_frames+min(holds[k],5)]
    assert all(a<b for a,b in zip(cuts,cuts[1:]))
    captions += [[a,b,g] for a,b,g in zip(cuts,cuts[1:],parts)]
    mix.append(frame_audio)
    cursor += shot_frames

assert not groups and 1500 <= cursor <= 1800, cursor
def stamp(frame):
    ms = round(1000*frame/30)
    return f'{ms//3600000:02}:{ms//60000%60:02}:{ms//1000%60:02},{ms%1000:03}'
(out/'EPISODE_002_SUBTITLES.srt').write_text('\n'.join(
    f'{i}\n{stamp(a)} --> {stamp(b)}\n{g}\n' for i,(a,b,g) in enumerate(captions,1)))
(root/'timing.json').write_text(json.dumps(dict(shots=shots,captions=captions),indent=2))
base = np.concatenate(mix)
def pcm(x):
    return np.int16(np.clip(x,-1,1)*32767)
write(root/'voice_native.wav',sr,pcm(base))
clean = resample_poly(base,320,147)
write(out/'EPISODE_002_VOICEOVER.wav',48000,pcm(clean))
t = np.arange(len(clean))/48000
ambience = .005*np.sin(2*np.pi*59*t)+.003*np.sin(2*np.pi*117*t)
def click(at, level, metal=False):
    start = round(at*48000)
    extent = min(len(clean)-start, 9500)
    x = np.arange(extent)/48000
    tone = np.sin(2*np.pi*(1760 if metal else 410)*x)
    wave = (tone*.4+rng.normal(0,.34,extent))*np.exp(-x*(46 if metal else 70))
    ambience[start:start+extent] += level*wave
for at in np.arange(.34,len(clean)/48000,2):
    click(at,.075)
for shot, fraction in [(0,.62),(1,.57),(9,.49),(9,.79)]:
    a,b=shots[shot]
    click((a+(b-a)*fraction)/30,.13,True)
write(root/'mix.wav',48000,pcm(clean+ambience))
print('Frames:',cursor,'shots:',shots)
