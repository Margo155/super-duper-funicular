#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$(realpath "$0")")/.."
tools_dir=${ODDPLOT_TOOLS:-/workspace/oddplot-tools}
python_bin=${ODDPLOT_PYTHON:-$tools_dir/venv/bin/python}
export ODDPLOT_TOOLS="$tools_dir"
export XDG_CACHE_HOME=${XDG_CACHE_HOME:-$tools_dir/cache}
export ODDPLOT_RENDER_THREADS=${ODDPLOT_RENDER_THREADS:-2}
export LP_NUM_THREADS="$ODDPLOT_RENDER_THREADS"
export ODDPLOT_FRAMES=${ODDPLOT_FRAMES:-$PWD/frames}
mkdir -p "$ODDPLOT_FRAMES" "$XDG_CACHE_HOME"
"$python_bin" source/narration.py
"$python_bin" source/mix.py "$ODDPLOT_FRAMES/MIX.wav"
blender -b -t "$ODDPLOT_RENDER_THREADS" --python-exit-code 1 -P source/episode_scene.py
blender -b EPISODE_001_SCENE.blend -t "$ODDPLOT_RENDER_THREADS" --python-exit-code 1 -P source/check_motion.py
blender -b EPISODE_001_SCENE.blend -t "$ODDPLOT_RENDER_THREADS" --python-exit-code 1 -P source/render_frames.py
bash source/encode.sh "$ODDPLOT_FRAMES" "$ODDPLOT_FRAMES/MIX.wav"
python3 source/verify.py
