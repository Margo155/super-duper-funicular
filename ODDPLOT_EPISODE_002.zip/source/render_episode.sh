#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
PYTHON_BIN=${ODDPLOT_PYTHON:-/workspace/.oddplot-venv/bin/python}
export LP_NUM_THREADS=${LP_NUM_THREADS:-3}
export MESA_SHADER_CACHE_DIR=${MESA_SHADER_CACHE_DIR:-/tmp/odd-mesa}
mkdir -p output
"$PYTHON_BIN" source/render.py --sample output/control_frames --video output/EPISODE_002_FINAL.mp4
"$PYTHON_BIN" source/qa/validate_video.py output/EPISODE_002_FINAL.mp4 --srt output/EPISODE_002_SUBTITLES.srt --report output/QA_REPORT.json
"$PYTHON_BIN" source/qa/make_review_sheets.py output/EPISODE_002_FINAL.mp4 --out output/review_sheets
ffmpeg -hide_banner -i output/EPISODE_002_FINAL.mp4 -vn -af volumedetect -f null - 2> output/QA_AUDIO_CHECK.txt
