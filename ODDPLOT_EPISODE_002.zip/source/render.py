"""Editable perspective clock room, articulated keeper and motion graphics."""
from pathlib import Path
import argparse, bisect, json, math, subprocess
import moderngl as gl
import numpy as np
from PIL import Image, ImageDraw, ImageFont

P = Path(__file__).resolve().parent
TIMING = json.loads((P/'timing.json').read_text())
SHOTS, CAPTIONS = TIMING['shots'], TIMING['captions']
W, H = 810, 1440
PI = math.pi
FONT = '/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf'
MONO = '/usr/share/fonts/truetype/dejavu/DejaVuSansMono.ttf'
IVORY, INK, GOLD, MINT = '#fff1d9','#12192a','#ffbc6f','#8de1d5'

def mat(pos=(0,0,0), size=(1,1,1), angle=0, axis='z'):
    c,s = math.cos(angle),math.sin(angle)
    if axis=='z':
        r = [[c,-s,0],[s,c,0],[0,0,1]]
    elif axis=='x':
        r = [[1,0,0],[0,c,-s],[0,s,c]]
    else:
        r = [[c,0,s],[0,1,0],[-s,0,c]]
    m = np.eye(4,dtype='f4')
    m[:3,:3],m[:3,3] = np.array(r)*size,pos
    return m

def rgb(hexcolor):
    return tuple(int(hexcolor[i:i+2],16)/255 for i in (0,2,4))

def unit(x):
    return x/np.linalg.norm(x)

def camera(eye, target, fov):
    z=unit(np.subtract(eye,target))
    x=unit(np.cross((0,1,0),z))
    y=np.cross(z,x)
    v=np.eye(4)
    v[:3,:3]=[x,y,z]
    v[:3,3]=-v[:3,:3]@eye
    f=1/math.tan(math.radians(fov)/2)
    p=np.array([[f*H/W,0,0,0],[0,f,0,0],[0,0,-1.002,-.10],[0,0,-1,0]])
    return (p@v).astype('f4')

def mesh_faces(faces):
    verts=[]
    for face in faces:
        a,b,c=map(np.asarray,face[:3])
        normal=unit(np.cross(b-a,c-a))
        for i in range(1,len(face)-1):
            for j in (0,i,i+1):
                verts.append((*face[j],*normal))
    return np.asarray(verts,dtype='f4')

def box_mesh():
    a,b,c,d=[(-.5,-.5,.5),(.5,-.5,.5),(.5,.5,.5),(-.5,.5,.5)]
    e,f,g,h=[(-.5,-.5,-.5),(.5,-.5,-.5),(.5,.5,-.5),(-.5,.5,-.5)]
    return mesh_faces([(a,b,c,d),(f,e,h,g),(e,a,d,h),(b,f,g,c),(d,c,g,h),(e,f,b,a)])

def round_mesh(n, teeth=False, hole=0):
    faces=[]
    r=[(1 if i%4 in (1,2) else .89) if teeth else 1 for i in range(n)]
    coords=[(math.cos(2*PI*i/n),math.sin(2*PI*i/n)) for i in range(n)]
    def pt(i,z,inner=False):
        x,y=coords[i]
        k=hole if inner else r[i]
        return (x*k,y*k,z)
    for i in range(n):
        j=(i+1)%n
        a,b,c,d=pt(i,.5),pt(j,.5),pt(j,-.5),pt(i,-.5)
        faces.append((d,c,b,a))
        if hole:
            e,f,g,h=pt(i,.5,True),pt(j,.5,True),pt(j,-.5,True),pt(i,-.5,True)
            faces.extend(((e,a,b,f),(c,d,h,g),(f,g,h,e)))
        else:
            faces.extend((((0,0,.5),a,b),((0,0,-.5),c,d)))
    return mesh_faces(faces)

VERT = """#version 330
in vec3 p; in vec3 n;
uniform mat4 view, model; uniform mat3 normals;
out vec3 pos, normal;
void main(){vec4 q=model*vec4(p,1);pos=q.xyz;normal=normals*n;gl_Position=view*q;}
"""
FRAG = """#version 330
uniform vec3 base,eye; uniform float metal,emit;
in vec3 pos,normal; out vec4 pixel;
void main(){
 vec3 n=normalize(normal), l=normalize(vec3(-.58,.8,.63)), v=normalize(eye-pos);
 float lam=max(0.,dot(n,l));
 float spec=pow(max(0.,dot(n,normalize(l+v))),mix(24.,46.,metal));
 float grain=fract(sin(dot(floor(pos*480.),vec3(12.7,38.1,17.3)))*43758.54)-.5;
 float key=0.75+0.28*exp(-pow((pos.x+.76+pos.y*.22)*.55,2.));
 vec3 c=base*(vec3(.49,.61,.66)+lam*key*vec3(.70,.49,.28))+
         spec*(.10+.38*metal)*vec3(1.,.76,.48)+grain*.012+base*emit;
 float fog=clamp((length(eye-pos)-4.)*.029,0.,.27);
 c=mix(c,vec3(.18,.26,.27),fog);
 pixel=vec4(c,1.);
}
"""

class Room:
    def __init__(self):
        self.ctx=gl.create_standalone_context(backend='egl')
        self.prog=self.ctx.program(vertex_shader=VERT,fragment_shader=FRAG)
        self.fb=self.ctx.simple_framebuffer((W,H),components=3)
        self.aa=self.ctx.simple_framebuffer((W,H),components=3,samples=2)
        self.ctx.enable(gl.DEPTH_TEST|gl.CULL_FACE)
        self.mesh={}
        for key,geometry in [('box',box_mesh()),('circle',round_mesh(44)),('rim',round_mesh(64,hole=.83))]:
            self.mesh[key]=self.ctx.vertex_array(self.prog,[(self.ctx.buffer(geometry.tobytes()),'3f 3f','p','n')])
        for z in (16,24,36):
            self.mesh[z]=self.ctx.vertex_array(self.prog,[(self.ctx.buffer(round_mesh(z*4,True,.73).tobytes()),'3f 3f','p','n')])
        self.static=[]
        self.cache={}
        self.build()

    def draw(self, mesh, transform, color, metallic=0, emit=0):
        pr=self.prog
        pr['model'].write(transform.T.astype('f4').tobytes())
        pr['normals'].write(np.linalg.inv(transform[:3,:3]).astype('f4').tobytes())
        pr['base'].value=rgb(color)
        pr['metal'].value=metallic
        pr['emit'].value=emit
        self.mesh[mesh].render(gl.TRIANGLES)

    def add(self, mesh, pos, size, color, metallic=0, angle=0, axis='z', emit=0):
        self.static.append((mesh,mat(pos,size,angle,axis),color,metallic,emit))

    def build(self):
        add=self.add
        add('box',(0,2.8,-3.25),(11,7,.2),'958879')
        add('box',(-2.65,-.13,0),(6.58,.25,13),'645449')
        add('box',(3.92,-.13,0),(4.52,.25,13),'645449')
        add('box',(1.14,-.13,-2.92),(1.02,.25,5.88),'645449')
        add('box',(1.14,-.13,2.7),(1.02,.25,3.15),'645449')
        add('box',(1.14,-.91,.53),(1.50,.14,1.70),'2b3334')
        add('box',(-4.5,2,0),(.23,5.8,9),'a39681')
        add('box',(4.5,2,0),(.23,5.8,9),'7b756a')
        add('box',(0,5.4,0),(10,.2,9),'574a40')
        for i in range(17):
            x=(i-8)*.54
            color=['736453','6b594d','7e6a55'][i%3]
            if i in (9,10):
                add('box',(x,-.009,-1.74),(.532,.04,3.52),color)
                add('box',(x,-.009,3.30),(.532,.04,4.40),color)
            else:
                add('box',(x,-.009,1),(.532,.04,9),color)
        for x in (-3.9,-2.8,2.52,3.9):
            add('box',(x,2.4,-3.04),(.22,5.6,.27),'aba08b')
        for y in (.27,1.1,2.08,3.06,4.04,5.0):
            add('box',(0,y,-3.11),(9,.045,.06),'796c60')
        for x in (-2.65,1.91):
            add('box',(x,1.9,-.82),(.21,3.8,.26),'25383a',.4)
            add('box',(x,.12,-.82),(.65,.22,.62),'28383a',.3)
        for y in (.56,3.77):
            add('box',(-.37,y,-.82),(4.8,.24,.28),'2d4241',.45)
        for x in (-2.48,2.26):
            add('box',(x,1.1,-.17),(.105,2.05,.12),'384948',.4)
            for y in (.54,1.57):
                add('box',(x,y,-.55),(.1,.095,.88),'405251',.4)
        for x in (-2.6,1.85):
            for y in (.56,3.77):
                add('circle',(x,y,-.66),(.11,.11,.055),'a9926f',.72)
        # The translucent-looking interior dial and raised hour marks.
        dial=(1.08,3.18,-2.97)
        add('circle',dial,(1.66,1.66,.11),'d5b477',.12,emit=.24)
        add('rim',(dial[0],dial[1],-2.87),(1.72,1.72,.07),'514332',.55)
        add('rim',(dial[0],dial[1],-2.81),(1.47,1.47,.026),'89734e',.55)
        for i in range(60):
            a=2*PI*i/60
            r=1.37 if i%5 else 1.25
            add('box',(dial[0]+r*math.sin(a),dial[1]+r*math.cos(a),-2.78),
                (.025 if i%5 else .05,.06 if i%5 else .18,.035),'635034',.45,-a)
        for a,l in ((-.87,1.09),(1.15,.78)):
            add('box',(dial[0]-math.sin(a)*l/2,dial[1]+math.cos(a)*l/2,-2.74),(.085,l,.05),'413735',.3,a)
        add('circle',(dial[0],dial[1],-2.70),(.12,.12,.08),'483b30',.6)
        # West window, lintel and mullions.
        add('box',(-3.19,3.39,-3.11),(1.06,1.98,.10),'393b35')
        for x in (-3.43,-2.96):
            for y in (3.01,3.8):
                add('box',(x,y,-3.01),(.41,.72,.025),'dacdab',emit=.45)
        add('box',(-3.19,2.44,-2.93),(1.22,.12,.35),'968471')
        for z in (.04,1.08):
            add('box',(1.08,.033,z),(1.05,.065,.09),'303a38',.35)
        for x in (.31,1.63):
            add('box',(x,.028,.56),(.08,.06,1.10),'303a38',.35)
        # Keeper's log and desk clock face sit on a low stand.
        add('box',(-1.65,.57,1.02),(.105,1.14,.13),'303e41')
        add('box',(-1.65,1.15,1.02),(.68,.095,.52),'5e3e30')
        add('box',(-1.65,1.215,1.01),(.46,.045,.33),'e6d1a5',angle=.19,axis='y')
        for k in range(6):
            add('box',(-1.65,1.239,.895+.041*k),(.32,.003,.006),'8b775a')
        add('circle',(-1.8,1.31,.96),(.10,.10,.042),'c6a46c',.65)
        add('circle',(-1.8,1.31,.99),(.078,.078,.015),'eee0bf')
        add('box',(-1.8,1.34,1.001),(.009,.059,.007),'333a3f',angle=-.44)

    def gear(self,x,y,z,r,teeth,phase,t):
        ang=phase+t*.13*24/teeth*(1 if teeth!=16 else -1)
        rot=mat((x,y,z),angle=ang)
        self.draw(teeth,rot@mat(size=(r,r,.15)), 'a6743d',.66)
        self.draw('rim',rot@mat((0,0,.075),(r*.91,r*.91,.039)),'d2a566',.76)
        for k in range(6):
            a=k*PI/3
            trans=rot@mat(angle=a)@mat((0,r*.48,0),(.105,r*.74,.12))
            self.draw('box',trans,'977443',.72)
        self.draw('circle',rot@mat(size=(r*.22,r*.22,.26)),'b38b50',.72)
        self.draw('circle',rot@mat((0,0,.16),(r*.12,r*.12,.13)),'445356',.65)
        self.draw('circle',mat((x,y,z-.41),(r*.11,r*.11,.81)),'4e5551',.54)

    def setup_view(self,eye,target,fov):
        self.vp=camera(eye,target,fov)
        self.aa.use()
        self.aa.clear(.12,.18,.19,1)
        self.prog['view'].write(self.vp.T.tobytes())
        self.prog['eye'].value=eye

    def project(self,p):
        q=self.vp@np.array((*p,1))
        return np.array(((.5+.5*q[0]/q[3])*W,(.5-.5*q[1]/q[3])*H))

    def coin(self, parent, x, y, z, radius=.075, angle=0):
        c=parent@mat((x,y,z), angle=angle,axis='y')@mat(angle=PI/2,axis='x')
        self.draw('circle',c@mat(size=(radius,radius,.022)),'bb713d',.76)
        self.draw('rim',c@mat((0,0,-.012),(radius*.94,radius*.94,.004)),'e1aa61',.74)
        self.draw('circle',c@mat((0,0,-.014),(radius*.40,radius*.50,.003)),'cb8a4c',.68)

    def render(self,eye,target,fov,t,shot,u):
        self.setup_view(eye,target,fov)
        for args in self.static:
            self.draw(*args)
        for x,y,z,r,n,p in [(-1.17,2.52,-.44,.98,24,.03),(.34,2.66,-.44,.651,16,.10),
                             (2.36,2.78,-.44,1.47,36,.05)]:
            self.gear(x,y,z,r,n,p,t)
        pend=mat((.73,3.81,.71),angle=.052*math.sin(t*PI/2))
        self.draw('circle',mat((.73,3.81,.73),(.22,.22,.32)),'7f938e',.6)
        self.draw('box',pend@mat((0,-2.23,0),(.073,4.46,.076)),'9ba197',.56)
        self.draw('box',pend@mat((0,-2.22,.04),(.02,4.44,.014)),'c6c5a6',.61)
        self.draw('circle',pend@mat((0,-4.04,.04),(.45,.51,.28)),'a5824a',.75)
        self.draw('rim',pend@mat((0,-4.04,.188),(.411,.47,.045)),'c2a169',.76)
        self.draw('box',pend@mat((-.22,-1.77,.17),(.64,.073,.38)),'a88756',.73)
        self.draw('box',pend@mat((-.14,-1.86,.17),(.33,.15,.18),-.24),'59635c',.6)
        for y in (-1.734,-1.711,-1.688):
            self.coin(pend,-.31,y+.021,.24)
        for x,z in ((-.05,.20),(-.42,.12)):
            self.coin(pend,x,-1.721,z,.059)
        contact=np.array([-.31,-1.644,.24,1.])
        grip=contact.copy()
        if shot==0:
            lift=1-smooth(.14,.62,u)
        elif shot==1:
            lift=smooth(.57,.91,u)
        elif shot==9:
            lift=1-smooth(.24,.49,u)+smooth(.79,.99,u)
        else:
            lift=0
        grip[:3]+=(-.45*lift,.30*lift,.21*lift)
        self.coin(pend,*grip[:3],angle=.6*lift)
        # Shadow is on the same floor plane as the sprite's ankle anchors.
        for x in (-.91,-.62):
            self.draw('circle',mat((x,.020,1.02),(.22,.13,.002),PI/2,'x'),'514638')
        self.ctx.copy_framebuffer(self.fb,self.aa)
        im=Image.frombytes('RGB',(W,H),self.fb.read(components=3)).transpose(Image.Transpose.FLIP_TOP_BOTTOM)
        return im, self.project((pend@grip)[:3]),self.project((pend@contact)[:3])

def smooth(a,b,x):
    q=max(0.,min(1.,(x-a)/(b-a)))
    return q*q*(3-2*q)

def cubic(start, bends):
    pts=[start]
    for a,b,c in bends:
        p=pts[-1]
        for k in range(1,13):
            u=k/12
            pts.append(tuple((1-u)**3*p[i]+3*(1-u)**2*u*a[i]+3*(1-u)*u*u*b[i]+u**3*c[i] for i in (0,1)))
    return pts

HAIR=cubic((-62,0),[
    ((-82,-28),(-43,-74),(2,-69)),((34,-66),(49,-65),(65,-88)),
    ((70,-67),(62,-44),(46,-32)),((49,-12),(27,-13),(16,-25)),
    ((1,-11),(-17,-7),(-50,-3)),((-61,13),(-67,20),(-62,0))])
LOCK=cubic((-55,-25),[((-47,-53),(-16,-64),(18,-60)),((34,-59),(48,-64),(53,-69)),
    ((32,-51),(13,-55),(-1,-54)),((-23,-52),(-41,-41),(-55,-25))])

def keeper(im,room,t,shot,u,coin,tray):
    d=ImageDraw.Draw(im)
    floor=room.project((-.76,.025,1.02))
    head=room.project((-.76,1.95,1.02))
    s=(floor[1]-head[1])/238
    if s<0 or s>11:
        return
    ox,oy=floor
    lean=3*math.sin(t*2)+ (8 if shot in (0,1,9) else 1)
    def xy(x,y):
        return (ox+x*s,oy+y*s)
    def poly(points,fill,outline=INK,width=4):
        d.polygon([xy(*p) for p in points],fill=fill)
        if outline:
            d.line([xy(*p) for p in [*points, points[0]]],fill=outline,width=max(1,round(width*s)),joint='curve')
    def line(points,color,width):
        d.line([xy(*p) for p in points],fill=color,width=max(1,round(s*width)),joint='curve')
    def ellipse(x,y,rx,ry,color,outline=None,sw=3):
        if rx>0 and ry>0:
            d.ellipse((*xy(x-rx,y-ry),*xy(x+rx,y+ry)),fill=color,outline=outline,width=max(1,round(sw*s)))
    # Fixed ankle positions are passed into both legs and shoe paths.
    for side in (-1,1):
        ankle=(side*24,-6)
        knee=(side*23+lean*.33,-40)
        hip=(side*16+lean,-77)
        line((hip,knee,ankle),INK,10)
        poly([(ankle[0]-7,ankle[1]-3),(ankle[0]+5,ankle[1]-4),(ankle[0]+12,-7),
              (ankle[0]+15,-2),(ankle[0]+15,0),(ankle[0]-7,0)],'#171c2a',INK,2)
    neck=(lean,-177)
    shoulders=((lean-26,-155),(lean+25,-155))
    glance=(1-smooth(.09,.24,u)) if shot in (1,9) else 0
    hand_x,hand_y=lean-34,-96
    if glance:
        lx,ly=(room.project((-1.65,1.25,1.17))-(ox,oy))/s
        hand_x+=(max(-82,lx)-hand_x)*glance*.72
        hand_y+=(ly-hand_y)*glance*.72
    line([(lean-23,-153),(lean-43,-121),(hand_x,hand_y)],INK,12)
    ellipse(hand_x,hand_y,8,8,IVORY,INK)
    poly([(lean-16,-168),(lean+11,-171),(lean+30,-153),(lean+34,-84),
          (lean+16,-78),(lean-29,-83),(lean-31,-150)],'#202941')
    poly([(lean-12,-168),(lean+10,-169),(lean+9,-151),(lean-7,-150)],IVORY)
    poly([(lean-17,-158),(lean-7,-145),(lean-7,-83),(lean-27,-87),(lean-29,-146)],'#ff820f')
    poly([(lean+12,-157),(lean+29,-152),(lean+31,-89),(lean+10,-83),(lean+6,-146)],'#eb6e14')
    for x in (-26,16):
        poly([(lean+x,-145),(lean+x+10,-147),(lean+x+10,-139),(lean+x,-137)],'#ffd2a0',None)
    line([(lean-28,-96),(lean+30,-99)],INK,7)
    poly([(lean-5,-101),(lean+6,-101),(lean+6,-94),(lean-5,-94)],'#d4b16a',INK,2)
    sx,sy=shoulders[1]
    if shot in (0,1,3,9):
        if shot==0:
            active=1-smooth(.62,.91,u)
        elif shot==1:
            active=smooth(.15,.45,u)*(1-smooth(.78,1,u))
        elif shot==9:
            active=smooth(.12,.36,u)*(1-smooth(.88,1,u))
        else:
            active=.77*math.sin(PI*u)**2
        dest=tray if shot==3 else coin
        tx,ty=(dest-(ox,oy))/s + (-7,-3)
        tx,ty=(1-active)*(lean+43)+active*tx,(1-active)*(-96)+active*ty
    else:
        tx,ty=lean+43,-96
    ex,ey=sx+(tx-sx)*.47,max(sy,ty)+16
    line([(sx,sy),(ex,ey),(tx,ty)],INK,13)
    line([(sx+1,sy),(ex+1,ey),(tx,ty)],'#242d43',7)
    ellipse(tx,ty,8,8,IVORY,INK)
    line([(tx+3,ty-2),(tx+4,ty+1)],'#a57b65',1.6)
    if shot==0:
        return
    hx,hy=lean+4,-221
    ellipse(hx-54,hy+12,13,17,IVORY,INK,5)
    ellipse(hx+53,hy+9,11,15,IVORY,INK,5)
    ellipse(hx,hy,54,63,IVORY,INK,5)
    poly([(hx+x,hy+y-4) for x,y in HAIR],'#151c2f')
    poly([(hx+x,hy+y-4) for x,y in LOCK],'#34415a',None)
    blink=abs((t+.43)%3.82-1.91)<.07
    look=(2 if shot in (0,1,3,4,9) else 0)-7*glance
    for x,y in [(-17,0),(19,-6)]:
        ellipse(hx+x+look,hy+y+3*glance,6.5,1.5 if blink else 10,INK)
        brow=cubic((hx+x-8,hy+y-13),[((hx+x-4,hy+y-21),(hx+x+4,hy+y-22),(hx+x+9,hy+y-15))])
        line(brow,INK,3)
    if shot in (1,5,8):
        ellipse(hx+7,hy+21,5.5,7,INK)
    else:
        line(cubic((hx-1,hy+21),[((hx+2,hy+30),(hx+14,hy+30),(hx+21,hy+17))]),INK,3)

CAMERAS=[
    ((.48,2.66,2.42),(.15,2.02,.65),44),
    ((.62,2.52,5.93),(-.53,1.51,.75),42),
    ((-1.80,3.26,7.05),(-.23,1.99,-.23),40),
    ((.76,2.90,3.91),(.20,2.05,.68),34),
    ((2.27,2.91,3.54),(.54,2.10,.60),34),
    ((-.92,2.75,6.1),(-.09,2.30,-.1),42),
    ((2.04,2.62,6.2),(.54,1.64,.4),45),
    ((1.17,2.74,5.02),(.46,2.39,.55),41),
    ((-1.04,2.70,6.55),(-.06,1.99,.26),39),
    ((.56,2.53,5.68),(-.42,1.52,.71),43),
    ((.85,2.54,2.68),(.38,2.11,.79),38),
]
MOVES=[(-.48,.08,.69),(-.55,-.12,.53),(2.2,-.18,.30),(-.43,-.06,-.34),
       (-.91,.05,-.28),(.36,.02,-.28),(-.48,.07,.14),(.49,.04,.61),
       (.65,-.04,-.37),(-.62,-.04,.18),(-.76,.20,5.20)]

from functools import lru_cache
@lru_cache
def font(size, mono=False):
    return ImageFont.truetype(MONO if mono else FONT,size)

def label(d,x,y,text,size=25,color=IVORY,anchor='mm',mono=False,stroke=0):
    d.text((x,y),text,font=font(size,mono),fill=color,anchor=anchor,
           stroke_width=stroke,stroke_fill=INK)

def panel(im,box,title,subtitle=None):
    d=ImageDraw.Draw(im)
    d.rounded_rectangle(box, radius=24, fill='#132428',outline='#607b73',width=2)
    x,y,r,_=box
    d.line((x+30,y+30,x+68,y+30),fill=GOLD,width=3)
    label(d,x+81,y+31,title,21,IVORY,'lm',True)
    if subtitle:
        label(d,r-28,y+31,subtitle,17,MINT,'rm',True)
    return d

def dash(d,x,y,stop,fill):
    for k in range(y,stop,16):
        d.line((x,k,x,min(k+8,stop)),fill=fill,width=3)

def graphic(im,shot,u,room,tray):
    d=ImageDraw.Draw(im)
    if shot==2 and .08<u<.80:
        d=panel(im,(76,300,518,516),'FOUR CLOCK FACES')
        # Four dials on the cardinal sides of the tower plan.
        cx,cy=298,418
        d.rectangle((cx-36,cy-36,cx+36,cy+36),outline='#516d68',width=3)
        for dx,dy in ((0,-47),(47,0),(0,47),(-47,0)):
            x,y=cx+dx,cy+dy
            d.ellipse((x-20,y-20,x+20,y+20),fill='#253e40',outline=GOLD,width=2)
            d.line((x,y-11,x,y,x+8,y+5),fill=IVORY,width=2)
    if shot==4:
        x,y=tray
        x=max(40,min(775,x))
        y=max(380,min(855,y))
        d.ellipse((x-34,y-26,x+34,y+26),outline=GOLD,width=3)
        d.line((x-36,y+10,210,879,120,879),fill=GOLD,width=2)
        label(d,115,905,'POSITION MATTERS',25,GOLD,'lm',True,2)
    if shot==5:
        d=panel(im,(69,328,741,915),'SIMPLIFIED MODEL')
        x=315
        y0,y1=457,767
        d.line((x-104,y0-20,x+104,y0-20),fill='#6a8681',width=4)
        d.line((x,y0,x,y1),fill='#d5cbb4',width=11)
        d.ellipse((x-14,y0-14,x+14,y0+14),fill=IVORY)
        d.ellipse((x-56,y1-40,x+56,y1+40),fill='#947248',outline=GOLD,width=3)
        d.line((x-64,558,x+30,558),fill='#d5cbb4',width=7)
        d.ellipse((x-40,545,x-15,554),fill=GOLD)
        if u>.23:
            lev=int(54*(1-smooth(.23,.40,u)))
            d.ellipse((x-40,538-lev,x-15,546-lev),fill=GOLD)
        label(d,x+36,480,'Pivot',21,IVORY,'lm')
        label(d,102,590,'Coin shelf',22,GOLD,'lm')
        label(d,104,770,'Main mass',22,IVORY,'lm')
        end=y1-int(66*smooth(.42,.68,u))
        dash(d,536,y0,end,MINT)
        for y in (y0,end):
            d.line((524,y,549,y),fill=MINT,width=4)
        label(d,554,575,'Effective',23,MINT,'lm')
        label(d,554,605,'length',23,MINT,'lm')
        label(d,405,860,'DIFFERENCE EXAGGERATED',23,IVORY,'mm',True)
    if shot==6:
        label(d,410,915,'ROD LENGTH UNCHANGED',29,GOLD,'mm',True,3)
        for y in (0,-4.45):
            a=.052*math.sin(room.time*PI/2)
            q=room.project((.73-y*math.sin(a),3.81+y*math.cos(a),.78))
            d.ellipse((q[0]-8,q[1]-8,q[0]+8,q[1]+8),fill=MINT)
    if shot==7 or (shot==8 and u<=.88):
        title='24 HOURS' if shot==7 else 'ACCUMULATED GAIN'
        sub='TIME COMPRESSED'
        d=panel(im,(69,383,741,876),title,sub)
        if shot==7:
            label(d,405,580,'+0.4 s / day',76,GOLD)
            label(d,405,657,'Per added old penny',31)
            label(d,405,702,'Relative to the prior rate',24,MINT)
        else:
            label(d,405,509,'≈21,600 full cycles',47,GOLD)
            label(d,105,597,'Prior rate',23,IVORY,'lm')
            label(d,105,686,'With one penny',23,MINT,'lm')
            p=smooth(.36,.87,u)
            d.line((326,598,660,598),fill='#667c76',width=3)
            d.line((326,688,660,688),fill='#667c76',width=3)
            d.ellipse((339+273*p,588,359+273*p,608),fill=IVORY)
            d.ellipse((339+306*p,678,359+306*p,698),fill=MINT)
            label(d,405,755,'DIFFERENCE EXAGGERATED',21,IVORY,'mm',True)
        x0,x1=105,704
        d.line((x0,802,x1,802),fill='#566b66',width=3)
        progress=smooth(.13,.90,u)
        d.line((x0,802,x0+(x1-x0)*progress,802),fill=GOLD,width=4)
        label(d,x0,836,'0 h',19,IVORY,'lm',True)
        label(d,x1,836,'24 h',19,IVORY,'rm',True)
    if shot==9 and .29<u<.90:
        label(d,405,881,'ADD' if u<.62 else 'REMOVE',30,GOLD,'mm',True,3)
    if shot==10 and u>.47:
        label(d,435,446,'5 tonnes',60,GOLD,'mm',stroke=3)
        label(d,435,500,'OF CLOCKWORK',20,IVORY,'mm',True,2)

def frame(room,n):
    shot=bisect.bisect_right([a for a,b in SHOTS],n)-1
    a,b=SHOTS[shot]
    u=(n-a)/(b-a-1)
    p=smooth(0,1,u)
    t=n/30
    room.time=t
    eye,target,fov=CAMERAS[shot]
    eye=tuple(v+p*d for v,d in zip(eye,MOVES[shot]))
    if shot==0:
        target=(target[0]-.23*(1-smooth(.12,.52,u)),target[1]+.12*(1-p),target[2])
    if shot==10:
        target=(target[0]-.63*p,target[1]-.60*p,target[2]-.27*p)
    im,coin,tray=room.render(eye,target,fov,t,shot,u)
    if shot not in (4,5,6,7) and (shot!=8 or u>.88):
        keeper(im,room,t,shot,u,coin,tray)
    graphic(im,shot,u,room,tray)
    for start,end,caption in CAPTIONS:
        if start<=n<end:
            label(ImageDraw.Draw(im),W//2,round(H*.72),caption,43,'#ffffff',stroke=4)
            break
    return im

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument('--sample',type=Path)
    ap.add_argument('--video',type=Path)
    ap.add_argument('--first',type=int,default=0)
    ap.add_argument('--last',type=int,default=SHOTS[-1][1])
    args=ap.parse_args()
    room=Room()
    print(room.ctx.info['GL_RENDERER'],flush=True)
    if args.sample:
        args.sample.mkdir(parents=True,exist_ok=True)
        for i,(a,b) in enumerate(SHOTS,1):
            n=a+round((b-a)*(.61 if i==1 else .67))
            frame(room,n).resize((1080,1920),Image.Resampling.LANCZOS).save(args.sample/f'{i:02}_{n:04}.png')
    if args.video:
        ff=subprocess.Popen(['ffmpeg','-v','warning','-y','-threads','2','-f','rawvideo','-pix_fmt','rgb24',
                 '-s',f'{W}x{H}','-r','30','-i','pipe:','-i',str(P/'mix.wav'),
                 '-map','0:v:0','-map','1:a:0','-af',f'atrim=start_sample={args.first*1600}:end_sample={args.last*1600},asetpts=PTS-STARTPTS',
                 '-vf','scale=1080:1920:flags=lanczos,setsar=1','-c:v','libx264','-threads','3',
                 '-preset','veryfast','-crf','17','-pix_fmt','yuv420p','-c:a','aac','-b:a','192k',
                 '-movflags','+faststart',str(args.video)],stdin=subprocess.PIPE)
        try:
            for n in range(args.first,args.last):
                ff.stdin.write(frame(room,n).tobytes())
                if n%150==0:
                    print(f'Frame {n}/{args.last}',flush=True)
        finally:
            ff.stdin.close()
            if ff.wait():
                raise RuntimeError('FFmpeg encoding failed')

if __name__=='__main__':
    main()
