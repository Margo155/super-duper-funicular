"""Render the locked text and align captions from Kokoro's duration predictor."""
import hashlib
import json
import os
from pathlib import Path
import re
import wave

import numpy as np
import onnx
import onnxruntime as ort
from kokoro_onnx.tokenizer import Tokenizer

OUT = Path(__file__).resolve().parents[1]
REPO = OUT.parents[1]
MODELS = Path(os.environ.get("ODDPLOT_TOOLS", "/workspace/oddplot-tools")) / "models"
RATE = 24000
SHOTS = [0, 165, 261, 343, 450]  # 30 fps
CAPTIONS = [
    ["People called", "the Coast Guard", "to report", "this vessel sinking.",
     "Its crew", "was doing it", "on purpose."],
    ["The stern dropped", "into the ocean.", "The bow climbed", "toward the sky."],
    ["And inside,", "there was a sink", "mounted sideways."],
    ["You might think", "the builders had", "made a terrible", "mistake."],
]


def stamp(sec):
    total = round(sec * 1000)
    minutes, milliseconds = divmod(total, 60_000)
    seconds, milliseconds = divmod(milliseconds, 1000)
    return f"00:{minutes:02}:{seconds:02},{milliseconds:03}"


def main():
    source = REPO / "audio/TEST_15S_VOICEOVER.txt"
    if source.exists():
        locked = source.read_bytes()
    else:
        script = (REPO / "EPISODE_001_SCRIPT.md").read_text()
        locked = (script.split("## Full approved narration\n\n", 1)[1]
                  .split("\n\nThen the whole", 1)[0] + "\n").encode()
    manifest = json.loads((REPO / "MANIFEST.json").read_text())
    expected = next(row["sha256"] for row in manifest if row["path"] == "audio/TEST_15S_VOICEOVER.txt")
    assert hashlib.sha256(locked).hexdigest() == expected
    assert locked.decode().split() == " ".join(sum(CAPTIONS, [])).split()
    (OUT / "source/VOICEOVER_LOCKED.txt").write_bytes(locked)

    model = onnx.load(MODELS / "kokoro-v1.0.int8.onnx")
    timing = "/encoder/Gather_output_0"
    model.graph.output.append(onnx.helper.make_tensor_value_info(timing, onnx.TensorProto.INT64, [None]))
    options = ort.SessionOptions()
    options.intra_op_num_threads = 2
    options.inter_op_num_threads = 1
    ort.set_seed(127001)
    runtime = ort.InferenceSession(model.SerializeToString(), options, providers=["CPUExecutionProvider"])
    tokenizer = Tokenizer()
    with np.load(MODELS / "voices-v1.0.bin") as voices:
        voice = voices["am_adam"]
    samples = np.zeros(15 * RATE, dtype=np.float32)
    cues = []
    for index, phrases in enumerate(CAPTIONS):
        text = " ".join(phrases)
        phonemes = tokenizer.phonemize(text, "en-us")
        if index == 1:
            # Select the nautical pronunciation, rhyming with "now".
            phonemes = re.sub(r"(?<=ðə )bˈoʊ(?= kl)", "bˈaʊ", phonemes)
        phonemes = phonemes.replace("ðɛɹw", "ðɛɹ w")
        units = phonemes.split()
        assert len(units) == len(text.split()), (text, phonemes)
        ids = tokenizer.tokenize(phonemes)
        start = SHOTS[index] / 30 + (0.08 if index == 0 else 0.045)
        available = SHOTS[index + 1] / 30 - start - (0.29 if index == 3 else 0.09)
        speed = 1.08
        for _ in range(7):
            audio, durations = runtime.run(["audio", timing], {
                "tokens": np.array([[0, *ids, 0]], np.int64),
                "style": voice[len(ids)], "speed": np.array([speed], np.float32),
            })
            audio = audio.reshape(-1)
            envelope = np.max(np.abs(audio[:len(audio) // 120 * 120]).reshape(-1, 120), axis=1)
            active = np.flatnonzero(envelope > 0.007)
            left = max(0, (active[0] - 5) * 120)
            right = min(len(audio), (active[-1] + 12) * 120)
            length = (right - left) / RATE
            if length <= available:
                break
            speed *= max(1.025, length / available * 1.015)
        assert length <= available
        print(index + 1, f"speed={speed:.3f}", f"audio={start:.3f}–{start+length:.3f}", phonemes, flush=True)
        signal = audio[left:right].copy()
        fade = np.linspace(0, 1, 96)
        signal[:96] *= fade
        signal[-96:] *= fade[::-1]
        sample_start = round(start * RATE)
        samples[sample_start:sample_start + len(signal)] = signal
        durations = durations.reshape(-1)
        assert len(durations) == len(ids) + 2
        assert abs(int(durations.sum()) * 600 - len(audio)) <= 600
        boundaries = np.insert(np.cumsum(durations), 0, 0) * 600
        word = 0
        for i, phrase in enumerate(phrases):
            before = len(tokenizer.tokenize(" ".join(units[:word]))) + (1 if word else 0)
            word += len(phrase.split())
            after = len(tokenizer.tokenize(" ".join(units[:word])))
            begin = start + max(0, (boundaries[1 + before] - left) / RATE - 0.028)
            end = start + min(length + 0.09, max(0, (boundaries[1 + after] - left) / RATE + 0.035))
            if i == 0:
                begin = start
            if i == len(phrases) - 1:
                end = min(SHOTS[index + 1] / 30 - 0.014, start + length + 0.10)
            cues.append((begin, end, phrase))

    samples *= 0.86 / np.max(np.abs(samples))
    with wave.open(str(OUT / "TEST_001_V3_VOICEOVER.wav"), "wb") as handle:
        handle.setparams((1, 2, RATE, 0, "NONE", "not compressed"))
        handle.writeframes(np.round(samples * 32767).astype("<i2").tobytes())

    blocks = []
    for i, (begin, end, phrase) in enumerate(cues):
        if i + 1 < len(cues):
            end = min(end, cues[i + 1][0] - 0.002)
        assert end > begin
        blocks.append(f"{i+1}\n{stamp(begin)} --> {stamp(end)}\n{phrase}\n")
    (OUT / "TEST_001_V3_SUBTITLES.srt").write_text("\n".join(blocks), encoding="utf-8")


if __name__ == "__main__":
    main()
