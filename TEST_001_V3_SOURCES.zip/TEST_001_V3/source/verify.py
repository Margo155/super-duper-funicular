"""Verify the rendered export and caption coverage."""
from hashlib import sha256
import json
from pathlib import Path
import re
import subprocess
import wave

OUT = Path(__file__).resolve().parents[1]


def probe(path, entries, count=False):
    args = ["ffprobe", "-v", "error", "-of", "json", "-show_entries", entries]
    if count:
        args.append("-count_frames")
    return json.loads(subprocess.check_output(args + [str(path)]))


def milliseconds(stamp):
    hh, mm, ss, ms = map(int, re.split("[:,]", stamp))
    return (hh * 3600 + mm * 60 + ss) * 1000 + ms


result = probe(OUT / "TEST_001_V3_15s.mp4",
               "stream=codec_type,codec_name,width,height,r_frame_rate,nb_read_frames,duration:format=duration",
               count=True)
assert result["format"]["duration"] == "15.000000", result
video = next(s for s in result["streams"] if s["codec_type"] == "video")
audio = next(s for s in result["streams"] if s["codec_type"] == "audio")
size = video["width"], video["height"]
assert size in {(540, 960), (1080, 1920)}, video
assert (video["nb_read_frames"], video["r_frame_rate"], video["codec_name"]) == ("450", "30/1", "h264"), video
assert audio["codec_name"] == "aac" and float(audio["duration"]) >= 14.96, audio
raw_audio = subprocess.check_output([
    "ffmpeg", "-v", "error", "-i", str(OUT / "TEST_001_V3_15s.mp4"), "-map", "0:a:0",
    "-f", "s16le", "-ac", "1", "-ar", "24000", "pipe:1"])
assert len(raw_audio) >= 15*24000*2
peaks = memoryview(raw_audio).cast("h")
assert max(map(abs, peaks)) > 15000, "Mixed audio is missing or nearly silent"
with wave.open(str(OUT / "TEST_001_V3_VOICEOVER.wav"), "rb") as voice:
    assert voice.getnframes() == voice.getframerate() * 15
captions = (OUT / "TEST_001_V3_SUBTITLES.srt").read_text().strip().split("\n\n")
previous = 0
captured_words = []
for number, entry in enumerate(captions, 1):
    idx, timing, text = entry.splitlines()
    assert int(idx) == number
    begin, end = map(milliseconds, timing.split(" --> "))
    assert 0 <= previous <= begin < end <= 15_000
    previous = end
    captured_words.extend(text.split())
assert captured_words == (OUT / "source" / "VOICEOVER_LOCKED.txt").read_text().split()
controls = sorted((OUT / "control_frames").glob("shot_*.png"))
assert len(controls) == len({sha256(p.read_bytes()).digest() for p in controls}) == 4
for p in controls:
    dimensions = probe(p, "stream=width,height")["streams"][0]
    assert (dimensions["width"], dimensions["height"]) == size
print(f"Verified {size[0]}×{size[1]}, 450 frames at 30 fps, 15.000 s, H.264 + audible AAC, "
      f"{len(captions)} timed cues / {len(captured_words)} words, and four distinct controls.")
