"""Make the full mix, reusing the approved first 15 seconds exactly."""
from pathlib import Path
import sys
import numpy as np
from narration import read_wave,write_wave,RATE,OUT,SOURCE
import json
voice=read_wave(OUT/"EPISODE_001_VOICEOVER.wav")
head=read_wave(SOURCE/"approved_opening/MIX.wav").reshape(-1,2)
tail=voice[len(head):]/32768
t=np.arange(len(tail))/RATE
rng=np.random.default_rng(127001)
def noise(lo,hi):
    frequencies=np.fft.rfftfreq(len(tail),d=1/RATE)
    envelope=(1-np.exp(-(frequencies/lo)**2))*np.exp(-(frequencies/hi)**2)
    signal=np.fft.irfft(np.fft.rfft(rng.normal(size=len(tail)))*envelope,n=len(tail))
    return signal/np.std(signal)
shots=json.loads((SOURCE/"edit.json").read_text())
room=np.zeros(len(tail))
for shot in (3,4,10):
    a=(shots[shot]["first"]-451)*(RATE//30)
    b=(shots[shot]["last"]-450)*(RATE//30)
    room[a:b]=1
fade=1800
for j in np.flatnonzero(np.diff(room)):
    first=max(0,j-fade)
    last=min(len(room),j+fade)
    room[first:last]=np.linspace(room[first],room[last-1],last-first)
air_start=(shots[11]["first"]-451)/30
air_gate=np.exp(-((t-air_start-.95)/.63)**2)
roll=noise(60,540)
wash=noise(320,2300)
level=np.minimum(np.clip(t/.17,0,1),np.clip((t[-1]-t)/.42,0,1))
ambience=level*((.009*roll+.006*wash)*(.44+.56*(1-room))+.009*wash*air_gate)
stereo=np.column_stack((.91*tail+ambience+.0017*wash*level,
                         .91*tail+ambience-.0017*wash*level))
result=np.concatenate((head,np.round(np.clip(stereo,-.98,.98)*32767).astype("<i2")))
write_wave(Path(sys.argv[1]),result,2)
