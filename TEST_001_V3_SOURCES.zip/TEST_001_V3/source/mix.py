"""Create the deterministic score-free ambience and spot effects."""
import math
from pathlib import Path
import sys
import wave

import numpy as np

OUT = Path(__file__).resolve().parents[1]
RATE = 24000
N = RATE * 15
rng = np.random.default_rng(127001)
t = np.arange(N) / RATE


def noise_band(lo, hi):
    f = np.fft.rfftfreq(N, 1 / RATE)
    tilt = (1 - np.exp(-(f / lo)**2)) * np.exp(-(f / hi)**2)
    signal = np.fft.irfft(np.fft.rfft(rng.normal(size=N)) * tilt, n=N)
    return signal / np.std(signal)


def pulse(at, decay):
    s = t - at
    return np.where(s >= 0, np.exp(-np.maximum(0, s) / decay), 0)


with wave.open(str(OUT / "TEST_001_V3_VOICEOVER.wav"), "rb") as stream:
    assert stream.getframerate() == RATE and stream.getnchannels() == 1
    voice = np.frombuffer(stream.readframes(N), dtype="<i2").astype(float) / 32768
assert len(voice) == N

rumble = noise_band(48, 410)
spray = noise_band(230, 2350)
detail = noise_band(830, 5400)
outside = 1 - np.clip((t - 8.68) / .13, 0, 1)
wave_wash = (.70 + .19 * np.sin(2 * math.pi * .38 * t)
                  + .11 * np.sin(2 * math.pi * .83 * t + .6))
ambience = outside * wave_wash * (.012 * rumble + .007 * spray)
ambience += (1 - outside) * (.004 * rumble + .002 * spray)
effects = .042 * detail * pulse(3.62, .035)
effects += .008 * spray * (pulse(3.74, .7) + .55 * pulse(6.44, .6))
effects += .025 * pulse(10.19, .095) * (
    np.sin(2 * math.pi * 443 * (t - 10.19)) + .29 * np.sin(2 * math.pi * 691 * (t - 10.19))
)
ambience *= np.minimum(np.clip(t / .12, 0, 1), np.clip((15 - t) / .36, 0, 1))
variation = .0018 * outside * noise_band(210, 2000)
left = voice * .91 + ambience + effects + variation
right = voice * .91 + ambience + effects - variation
pcm = np.clip(np.column_stack((left, right)), -.98, .98)
with wave.open(sys.argv[1], "wb") as stream:
    stream.setparams((2, 2, RATE, 0, "NONE", "not compressed"))
    stream.writeframes(np.round(pcm * 32767).astype("<i2").tobytes())
