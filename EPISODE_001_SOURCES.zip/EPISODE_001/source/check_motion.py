"""Check the visible actor rigs at every frame and verify the cut list has no gaps."""
import json
import math
import bpy
from mathutils import Vector

scene=bpy.context.scene
cuts=json.loads(scene["episode_shots"])
actors=[
    ("Oddplot • deck station",1,261,(0,0,1.65),False),
    ("Oddplot • dry cabin",262,450,(0,0,0),False),
]
for cut in cuts:
    if cut["name"].startswith("06 "):
        actors += [(name,cut["first"],cut["last"],(0,0,1.65),True)
                   for name in ("Deployment crew · approved hero","Second crew member")]
    if cut["name"].startswith("08 "):
        actors += [("Hero · former bulkhead",cut["first"],cut["last"],(12.65,0,0),True)]
    if cut["name"].startswith("16 "):
        actors += [("Hero · lab station",cut["first"],cut["last"],(0,0,0),True)]

def children(actor,prefix):
    return sorted([obj for obj in actor.children if obj.name.startswith(prefix)],key=lambda o:o.name)

def segment(obj):
    return tuple(obj.matrix_basis @ Vector((0,0,z)) for z in (0,1))

def component(v):
    return Vector((v.x,v.z))

rigs=[]
for name,first,last,surface,new in actors:
    root=bpy.data.objects[name]
    nodes={key:children(root,prefix) for key,prefix in {
        "toe":"Shoe toe pivot","thigh":"Navy trouser leg","shin":"Navy ankle",
        "hand":"Hand","upper":"Flat upper sleeve","fore":"Flat forearm",
        "chest":"Weight shift over locked soles"}.items()}
    rigs.append((root,first,last,surface,new,nodes))

assert cuts[0]["first"]==1
for a,b in zip(cuts,cuts[1:]):
    assert a["last"]+1==b["first"],(a,b)
assert cuts[-1]["last"]==scene["last_frame"]

worst_opening=[0,0]
instances=0
for frame in range(1,scene["last_frame"]+1):
    scene.frame_set(frame)
    for root,first,last,surface,new,nodes in rigs:
        if not first<=frame<=last:
            continue
        instances+=1
        for index in (0,1):
            toe,thigh,shin,upper,fore,hand=(nodes[k][index] for k in
                ("toe","thigh","shin","upper","fore","hand"))
            shoe=next(obj for obj in toe.children if obj.name.startswith("Flat dark deck shoe"))
            socket=next(obj for obj in toe.children if obj.name.startswith("Ankle seated"))
            hip,knee=segment(thigh)
            shin_start,ankle=segment(shin)
            assert (shin_start-knee).length<.0001,(frame,root.name,index,"knee")
            assert (toe.matrix_basis @ socket.location - ankle).length<.0001,(frame,root.name,index,"ankle")
            sign=-1 if index==0 else 1
            expected_hip=nodes["chest"][0].matrix_basis @ Vector((sign*.126,0,-.284))
            assert (expected_hip-hip).length<.0001,(frame,root.name,index,"hip")
            vertices=[toe.matrix_basis @ shoe.matrix_basis @ v.co for v in shoe.data.vertices]
            assert abs(min(v.z for v in vertices))<.0001,(frame,root.name,index,"sole contact")
            normal=0 if surface[0] else 2
            height=surface[normal]
            deck_points=[(root.matrix_basis@v)[normal] for v in vertices]
            assert abs(min(deck_points)-height)<.0002,(frame,root.name,index,"deck contact")
            if index==1 or root.name!="Oddplot • deck station" or not 111<frame<159:
                assert abs(toe.rotation_euler.y)<.0001,(frame,root.name,index,"heel motion")
            shoulder,elbow=segment(upper)
            elbow_b,wrist=segment(fore)
            elbow_gap=(component(elbow)-component(elbow_b)).length
            wrist_gap=(component(wrist)-component(hand.location)).length
            arm_error=max(elbow_gap,wrist_gap)
            if new:
                target=nodes["chest"][0].matrix_basis @ Vector((sign*.205,0,.158))
                assert (target-shoulder).length<.0001,(frame,root.name,index,"shoulder")
                assert arm_error<.0001,(frame,root.name,index,"arm ends")
            else:
                worst_opening[0]=max(worst_opening[0],elbow_gap)
                worst_opening[1]=max(worst_opening[1],wrist_gap)
                assert elbow_gap<.040 and wrist_gap<.052,(frame,root.name,index,elbow_gap,wrist_gap)
print(f"{scene['last_frame']} edited frames, {instances} visible actor-frames.")
print(f"Approved opening maximum arm endpoint offset {worst_opening} m (elbow, wrist).")
