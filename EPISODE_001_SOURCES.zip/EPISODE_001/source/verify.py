"""Validate the final MP4 and the exact complete script against the edit clock."""
import json
from pathlib import Path
import re
import subprocess
import wave

OUT=Path(__file__).resolve().parents[1]
SRC=OUT/"source"
edit=json.loads((SRC/"edit.json").read_text())
frame_count=edit[-1]["last"]
expected_duration=frame_count/30
video=OUT/"EPISODE_001.mp4"
probe=json.loads(subprocess.check_output([
    "ffprobe","-v","error","-show_entries",
    "format=duration:stream=codec_name,codec_type,width,height,r_frame_rate,nb_read_frames,duration",
    "-count_frames","-of","json",str(video),
]))
picture=next(s for s in probe["streams"] if s["codec_type"]=="video")
sound=next(s for s in probe["streams"] if s["codec_type"]=="audio")
assert (picture["width"],picture["height"])==(1080,1920),picture
assert (picture["codec_name"],picture["r_frame_rate"],int(picture["nb_read_frames"]))==("h264","30/1",frame_count),picture
assert sound["codec_name"]=="aac" and abs(float(sound["duration"])-expected_duration)<.040,sound
assert abs(float(probe["format"]["duration"])-expected_duration)<.040
script=(SRC/"EPISODE_001_SCRIPT.md").read_text().split("## Full approved narration\n\n",1)[1].split("\n## ",1)[0]
words=[]
prior=0
cue_count=0
def time(stamp):
    hours,minutes,seconds,ms=map(int,re.split("[:,]",stamp))
    return (3600*hours+60*minutes+seconds)*1000+ms
for cue_count,block in enumerate((OUT/"EPISODE_001_SUBTITLES.srt").read_text().strip().split("\n\n"),1):
    identifier,timing,*lines=block.splitlines()
    assert int(identifier)==cue_count
    begin,end=map(time,timing.split(" --> "))
    assert prior<=begin<end<=round(expected_duration*1000),(cue_count,begin,end)
    prior=end
    words.extend(" ".join(lines).split())
assert words==script.split()
with wave.open(str(OUT/"EPISODE_001_VOICEOVER.wav"),"rb") as full:
    with wave.open(str(SRC/"approved_opening/TEST_001_V3_VOICEOVER.wav"),"rb") as start:
        assert full.readframes(start.getnframes())==start.readframes(start.getnframes())
    assert full.getframerate()==24_000 and full.getnframes()==frame_count*800
audio=subprocess.check_output([
    "ffmpeg","-v","error","-i",str(video),"-map","0:a:0",
    "-f","s16le","-ac","1","-ar","24000","pipe:1",
])
full=memoryview(audio).cast("h")
assert len(full)>=round((expected_duration-.03)*24_000)
assert all(max(map(abs,full[(beat["first"]-1)*800:beat["last"]*800]))>1000 for beat in edit)
print(f"Verified {frame_count} native 1080×1920 frames at 30 fps, {expected_duration:.3f} s, "
      f"{cue_count} English cues, {len(words)} approved words, exact opening voice and audible AAC.")
