"""Validate the baked connections and deck contact in every edited frame."""
import bpy
from mathutils import Vector

scene = bpy.context.scene
stations = {}
for label in ("deck station", "dry cabin"):
    root = bpy.data.objects[f"Oddplot • {label}"]
    def ordered(prefix, objects=root.children):
        return sorted((obj for obj in objects if obj.name.startswith(prefix)), key=lambda obj: obj.name)
    toes = ordered("Shoe toe pivot")
    stations[label] = (
        root, toes, ordered("Navy trouser leg"), ordered("Navy ankle"),
        ordered("Weight shift over locked soles")[0],
    )

def segment(obj):
    # The strip lies in the x-z plane, with centerline endpoints at z=0 and z=1.
    return tuple(obj.matrix_basis @ Vector((0,0,z)) for z in (0,1))

for frame in range(1,451):
    scene.frame_set(frame)
    root, toes, thighs, shins, pelvis = stations["deck station" if frame < 262 else "dry cabin"]
    for index, (toe, thigh, shin) in enumerate(zip(toes, thighs, shins, strict=True)):
        hip, knee = segment(thigh)
        shin_start, ankle = segment(shin)
        shoe = next(obj for obj in toe.children if obj.name.startswith("Flat dark deck shoe"))
        socket = next(obj for obj in toe.children if obj.name.startswith("Ankle seated inside shoe"))
        target = toe.matrix_basis @ socket.location
        assert (shin_start-knee).length < .0001, (frame, index, "knee gap")
        assert (target-ankle).length < .0001, (frame, index, "shoe gap")
        expected_hip = pelvis.matrix_basis @ Vector(((-1 if index == 0 else 1)*.126,0,-.284))
        assert (expected_hip-hip).length < .0001, (frame, index, "hip gap")
        vertices = [toe.matrix_basis @ shoe.matrix_basis @ v.co for v in shoe.data.vertices]
        assert abs(min(v.z for v in vertices)) < .0001, (frame, index, "floor contact")
        if index == 1 or frame not in range(112,159):
            assert abs(toe.rotation_euler.y) < .0001, (frame, index, "unexpected heel lift")
print("Checked 450 frames: both knees/ankles attached, support shoe flat, free toe in contact.")
