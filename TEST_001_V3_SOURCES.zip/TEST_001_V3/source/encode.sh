#!/usr/bin/env bash
set -euo pipefail
frames=$(realpath "${1:?Provide a directory with frames f_0001.jpg through f_0450.jpg}")
mix=$(realpath "${2:?Provide the generated mix WAV}")
cd "$(dirname "$(realpath "$0")")/.."
for ((i=1; i<=450; i++)); do
    printf -v file 'f_%04d.jpg' "$i"
    test -s "$frames/$file"
done
export XDG_CACHE_HOME="${XDG_CACHE_HOME:-/workspace/oddplot-tools/cache}"
mkdir -p "$XDG_CACHE_HOME" control_frames
staging=$(mktemp -d .encode.XXXXXX)
trap 'rm -rf -- "$staging"' EXIT
# Keep the caption proportions the same in both delivery sizes.
frame_size=$(ffprobe -v error -show_entries stream=width,height -of csv=p=0 "$frames/f_0001.jpg")
case "$frame_size" in
    540,960) export_width=540; export_height=960 ;;
    1080,1920) export_width=1080; export_height=1920 ;;
    *) echo "Unexpected frame size: $frame_size" >&2; exit 1 ;;
esac
captions="FontName=DejaVu Sans,FontSize=13,Bold=1,PrimaryColour=&H00FFFFFF,OutlineColour=&H0010131C,BorderStyle=1,Outline=1.34,Shadow=0,Alignment=2,MarginV=35"
ffmpeg -hide_banner -loglevel error -y -threads 2 \
    -framerate 30 -start_number 1 -i "$frames/f_%04d.jpg" -i "$mix" \
    -filter_threads 2 \
    -vf "scale=${export_width}:${export_height}:out_color_matrix=bt709:out_range=tv,format=yuv420p,subtitles=TEST_001_V3_SUBTITLES.srt:force_style='$captions'" \
    -map 0:v:0 -map 1:a:0 -t 15 -r 30 \
    -c:v libx264 -threads 3 -preset medium -crf 15 -pix_fmt yuv420p \
    -color_range tv -colorspace bt709 -color_trc bt709 -color_primaries bt709 \
    -c:a aac -ar 48000 -b:a 192k -movflags +faststart "$staging/TEST_001_V3_15s.mp4"
for frame in '132 shot_01_valve' '241 shot_02_pitch' '315 shot_03_sink' '422 shot_04_reaction'; do
    read -r number label <<< "$frame"
    ffmpeg -hide_banner -loglevel error -y -i "$staging/TEST_001_V3_15s.mp4" \
        -vf "select=eq(n\\,$((number - 1)))" -frames:v 1 -threads 1 "$staging/$label.png"
done
mv -- "$staging"/shot_*.png control_frames/
mv -- "$staging/TEST_001_V3_15s.mp4" TEST_001_V3_15s.mp4
