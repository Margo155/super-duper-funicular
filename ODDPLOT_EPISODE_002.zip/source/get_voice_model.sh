#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
archive=$(mktemp)
trap 'rm -f "$archive"' EXIT
curl -fLSs -o "$archive" https://github.com/k2-fsa/sherpa-onnx/releases/download/tts-models/vits-piper-en_GB-alan-medium.tar.bz2
printf '%s  %s\n' a48d4017da0f77668b27bed63fe6e04dd64c6397e1fadad4f460efb0ef7c9012 "$archive" | sha256sum -c -
tar -xjf "$archive" --strip-components=1 --wildcards '*/en_GB-alan-medium.onnx*' '*/MODEL_CARD'
