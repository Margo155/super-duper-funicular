#!/usr/bin/env bash
set -euo pipefail

tools_dir=${ODDPLOT_TOOLS:-/workspace/oddplot-tools}
for program in blender ffmpeg ffprobe python3 curl sha256sum; do
    if ! command -v "$program" >/dev/null; then
        printf 'Required cloud image program is missing: %s\n' "$program" >&2
        exit 1
    fi
done
mkdir -p "$tools_dir/models" "$tools_dir/cache"
if [[ ! -x "$tools_dir/venv/bin/python" ]]; then
    python3 -m venv "$tools_dir/venv"
fi
XDG_CACHE_HOME="$tools_dir/cache" "$tools_dir/venv/bin/pip" --disable-pip-version-check install \
    'kokoro-onnx==0.5.0' 'onnxruntime==1.23.2' 'onnx==1.20.1'
release=https://github.com/thewh1teagle/kokoro-onnx/releases/download/model-files-v1.0

fetch_model() {
    local name=$1 expected=$2 target="$tools_dir/models/$1" temporary
    if [[ -f "$target" ]] && printf '%s  %s\n' "$expected" "$target" | sha256sum -c --status; then
        return
    fi
    temporary=$(mktemp "$tools_dir/models/part.XXXXXX")
    if curl --fail --silent --show-error --location --retry 2 "$release/$name" -o "$temporary" &&
        printf '%s  %s\n' "$expected" "$temporary" | sha256sum -c --status; then
        mv "$temporary" "$target"
    else
        rm -f "$temporary"
        printf 'Could not download and verify %s\n' "$name" >&2
        return 1
    fi
}

fetch_model kokoro-v1.0.int8.onnx 6e742170d309016e5891a994e1ce1559c702a2ccd0075e67ef7157974f6406cb
fetch_model voices-v1.0.bin bca610b8308e8d99f32e6fe4197e7ec01679264efed0cac9140fe9c29f1fbf7d
blender --version | sed -n '1p'
ffmpeg -version | sed -n '1p'
"$tools_dir/venv/bin/python" -c 'import kokoro_onnx, onnx, onnxruntime'
