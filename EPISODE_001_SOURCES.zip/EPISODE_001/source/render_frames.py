"""Render the edit by shot and resume from the first missing complete JPEG."""
import bpy
from pathlib import Path
import json
import os

scene=bpy.context.scene
folder=Path(os.environ["ODDPLOT_FRAMES"]).resolve()
folder.mkdir(parents=True,exist_ok=True)
shots=json.loads(scene["episode_shots"])
allow=set(os.environ.get("ODDPLOT_SHOTS","").split(","))-{""}
sample=os.environ.get("ODDPLOT_SAMPLE")=="1"
bounds=os.environ.get("ODDPLOT_RANGE")
bounds=tuple(map(int,bounds.split(":"))) if bounds else None
groups=set(json.loads(scene["episode_groups"]))
sun=bpy.data.lights["Warm low sun"]
collections={name:bpy.data.collections[name] for name in json.loads(scene["episode_collections"])}
opening_lights={"Warm window bounce","Cool off-axis interior fill","Warm lamp pool","Soft ceramic edge light"}
for cut in shots:
    number=cut["name"].split(" ",1)[0]
    if allow and number not in allow:
        continue
    mode=cut["mode"]
    active={*cut["groups"],"Camera · "+cut["name"]}
    if mode in {"ocean","comparison","opening-exterior"}:
        active.update(("Set · far ocean","Set · water surface"))
    if mode in {"ocean","opening-exterior"}:
        active.add("Set · original hull")
    if mode=="opening-exterior":
        active.add("Set · approved deck actor")
    if mode=="opening-cabin":
        active.update(("Set · approved cabin","Set · far ocean"))
    for name,c in collections.items():
        if name.startswith(("Camera ·","Set ·")) or name in groups:
            c.hide_render=name not in active
    for obj in scene.objects:
        if obj.type=="LIGHT":
            obj.hide_render=not (obj.data==sun or obj.name==cut["light"] or
                                 (mode=="opening-cabin" and obj.name in opening_lights))
    sun.energy=2.15 if mode in {"ocean","comparison","opening-exterior"} else 0
    bpy.data.lights["Cool off-axis interior fill"].use_shadow=False
    bpy.data.lights["Warm window bounce"].use_shadow=False
    scene.eevee.shadow_pool_size="256"
    scene.eevee.shadow_step_count=4 if mode=="opening-exterior" else 3
    scene.eevee.use_shadows=mode.startswith("opening") or number in {"06","08"}
    scene.render.resolution_percentage=50 if sample else 100
    scene.camera=bpy.data.objects[cut["name"]]
    first,last=cut["first"],cut["last"]
    if bounds:
        first,last=max(first,bounds[0]),min(last,bounds[1])
        if first>last:
            continue
    if sample:
        frame=(first+last)//2
        scene.frame_set(frame)
        scene.render.filepath=str(folder/f"sample_{number}_{frame:04}.jpg")
        bpy.ops.render.render(write_still=True)
        continue
    while first<=last:
        candidate=folder/f"f_{first:04}.jpg"
        if not candidate.is_file() or candidate.stat().st_size < 100:
            break
        with candidate.open("rb") as file:
            file.seek(-2,2)
            if file.read()!=b"\xff\xd9":
                break
        first+=1
    if first>last:
        continue
    print(f"Rendering {cut['name']} · {first}–{last}",flush=True)
    scene.frame_start,scene.frame_end=first,last
    scene.frame_set(first)
    scene.render.filepath=str(folder/"f_")
    bpy.ops.render.render(animation=True)
