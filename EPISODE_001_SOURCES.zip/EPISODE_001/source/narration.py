"""Continue the approved voice track and derive captions from phoneme timings."""
import json
from pathlib import Path
import re
import wave
import numpy as np
import onnx
import onnxruntime as ort
from kokoro_onnx.tokenizer import Tokenizer
from kokoro_reference import MODELS, RATE, stamp

OUT = Path(__file__).resolve().parents[1]
SOURCE = OUT / "source"
BASE = SOURCE / "approved_opening"
CUES = [
    ["Then the whole thing", "started tilting."],
    ["The crew put on", "life jackets,", "grabbed their handholds,", "and prepared to", "step onto the walls."],
    ["Because those walls", "were about to", "become the floor."],
    ["As the vessel", "swung upright,", "the beds rotated", "to stay level."],
    ["The sideways sink", "finally made sense."],
    ["Three hundred feet", "of the structure", "disappeared underwater."],
    ["And that was when", "the scientists", "could start work."],
    ["You see, this was FLIP,", "a floating research platform", "designed to stand on end."],
    ["An ordinary ship", "rolls and pitches", "with the waves,", "shaking the instruments", "trying to measure them."],
    ["FLIP stretched deep", "below the surface,", "making it", "much more stable."],
    ["Scientists could study", "ocean sounds and currents", "while their laboratory", "barely moved."],
    ["When they finished,", "compressed air pushed", "the water out", "of the tanks,", "and FLIP lay back down."],
    ["So the sinking ship", "people reported", "was a laboratory", "getting ready for work."],
]

def read_wave(path):
    with wave.open(str(path),"rb") as f:
        return np.frombuffer(f.readframes(f.getnframes()),dtype="<i2").copy()

def write_wave(path, samples, channels=1):
    with wave.open(str(path),"wb") as f:
        f.setparams((channels,2,RATE,0,"NONE","not compressed"))
        f.writeframes(samples.astype("<i2").tobytes())

def main():
    script = (SOURCE / "EPISODE_001_SCRIPT.md").read_text()
    paragraphs=script.split("## Full approved narration\n\n",1)[1].split("\n## ",1)[0].strip().split("\n\n")
    assert [" ".join(group) for group in CUES] == paragraphs[4:]
    model=onnx.load(MODELS / "kokoro-v1.0.int8.onnx")
    timing="/encoder/Gather_output_0"
    model.graph.output.append(onnx.helper.make_tensor_value_info(timing,onnx.TensorProto.INT64,[None]))
    options=ort.SessionOptions()
    options.intra_op_num_threads=2
    options.inter_op_num_threads=1
    ort.set_seed(127001)
    session=ort.InferenceSession(model.SerializeToString(),options,providers=["CPUExecutionProvider"])
    tokenizer=Tokenizer()
    with np.load(MODELS/"voices-v1.0.bin") as voices:
        voice=voices["am_adam"]
    start=450
    blocks=[]
    audio_segments=[]
    edit=[]
    for index,(text,groups) in enumerate(zip(paragraphs[4:],CUES,strict=True)):
        phonemes=tokenizer.phonemize(text.replace("FLIP","Flip"),"en-us")
        phonemes=phonemes.replace("ʌvðə","ʌv ðə").replace("ðɛɹw","ðɛɹ w").replace("wɪððə","wɪð ðə").replace("ˌaʊɾəv","ˌaʊt əv").replace("wʌzɐ","wʌz ɐ")
        units=phonemes.split()
        ids=tokenizer.tokenize(phonemes)
        assert len(units)==len(text.split()),(text,phonemes)
        audio,durations=session.run(["audio",timing],{
            "tokens":np.array([[0,*ids,0]],np.int64),"style":voice[len(ids)],
            "speed":np.array([1.11],np.float32)})
        audio=audio.reshape(-1)
        active=np.flatnonzero(np.max(np.abs(audio[:len(audio)//120*120].reshape(-1,120)),axis=1)>.007)
        left=max(0,(active[0]-5)*120)
        right=min(len(audio),(active[-1]+10)*120)
        signal=audio[left:right].copy()
        fade=np.linspace(0,1,96)
        signal[:96]*=fade
        signal[-96:]*=fade[::-1]
        lead=.10
        tail=(.48 if index in (4,5,7,11) else .19) if index<12 else .85
        span=int(np.ceil((lead+len(signal)/RATE+tail)*30))
        laid=np.zeros(span*(RATE//30),np.float32)
        laid[round(lead*RATE):round(lead*RATE)+len(signal)]=signal
        audio_segments.append(laid)
        bounds=np.insert(np.cumsum(durations.reshape(-1)),0,0)*600
        assert len(bounds)==len(ids)+3 and abs(bounds[-1]-len(audio))<=600
        word=0
        for i,phrase in enumerate(groups):
            before=len(tokenizer.tokenize(" ".join(units[:word])))+(1 if word else 0)
            word+=len(phrase.split())
            after=len(tokenizer.tokenize(" ".join(units[:word])))
            begin=lead+max(0,(bounds[1+before]-left)/RATE-.028) if i else lead
            end=lead+min(len(signal)/RATE+.055,max(0,(bounds[1+after]-left)/RATE+.035))
            if i==len(groups)-1:
                end=lead+len(signal)/RATE+.04
            blocks.append([start/30+begin,start/30+end,phrase])
        edit.append({"first":start+1,"last":start+span,"narration":text})
        start+=span
    tail=np.concatenate(audio_segments)
    tail*=.86/np.max(np.abs(tail))
    combined=np.concatenate([read_wave(BASE/"TEST_001_V3_VOICEOVER.wav"),np.round(tail*32767).astype("<i2")])
    assert len(combined)==start*(RATE//30)
    write_wave(OUT/"EPISODE_001_VOICEOVER.wav",combined)
    srt=(BASE/"TEST_001_V3_SUBTITLES.srt").read_text().strip()
    original=len(srt.split("\n\n"))
    for i,(begin,end,phrase) in enumerate(blocks):
        if i+1<len(blocks):
            end=min(end,blocks[i+1][0]-.002)
        assert begin<end,(begin,end,phrase)
        srt+=f"\n\n{original+i+1}\n{stamp(begin)} --> {stamp(end)}\n{phrase}"
    (OUT/"EPISODE_001_SUBTITLES.srt").write_text(srt+"\n")
    (SOURCE/"edit.json").write_text(json.dumps(edit,indent=2)+"\n")
    for i,beat in enumerate(edit):
        print(i,beat["first"],beat["last"],beat["narration"])
    print(f"{start} frames, {start/30:.3f} s")

if __name__=="__main__":
    main()
