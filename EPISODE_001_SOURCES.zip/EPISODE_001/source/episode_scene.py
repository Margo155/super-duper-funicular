"""Build the full edit around the approved 15-second Blender scene."""
import json
from pathlib import Path
import sys

SOURCE=Path(__file__).resolve().parent
sys.path.insert(0,str(SOURCE))
from opening_scene import *

edit=json.loads((SOURCE/"edit.json").read_text())
end=edit[-1]["last"]
scene.frame_end=end
shots=[]

def span(index):
    return edit[index]["first"],edit[index]["last"]

def fraction(index,part):
    a,b=span(index)
    return round(a+(b-a)*part)

def section(name,x=0,parent=None):
    return empty(name,parent,(x,0,0))

def shot(name,first,last,keys,mode,groups=(),light=None):
    cam=camera(name)
    for f,eye,target,lens in keys:
        camera_key(cam,f,eye,target,lens)
    scene.timeline_markers.new(name,frame=first).camera=cam
    shots.append({"name":name,"first":first,"last":last,"mode":mode,
                  "groups":[g.name for g in groups],"light":light.name if light else None})
    return cam

def banner(cam,text,small=None):
    root=empty(text+" • annotation",cam,(0,0,-2.0))
    root.rotation_euler.x=-math.pi/2
    # Use camera coordinates so labels stay within the upper portrait safe area.
    width=2*cam.data.sensor_height/cam.data.lens
    z=width*.32
    size=width*.050
    backing=[(-width*.245,z+size*.85),(width*.245,z+size*.85),
             (width*.245,z-size*(1.65 if small else .63)),(-width*.245,z-size*(1.65 if small else .63))]
    xy("Navy annotation backing",backing,0,NAVY,root)
    obj=lettering(text,text,(0,-.003,z),min(size,width*.43/(.62*len(text))),FACE,root)
    obj.data.align_x="CENTER"
    obj.data.align_y="CENTER"
    if small:
        obj=lettering(small,small,(0,-.003,z-size*1.02),min(size*.54,width*.44/(.62*len(small))),REFLECT,root)
        obj.data.align_x="CENTER"
        obj.data.align_y="CENTER"

def stage_light(name,x,energy=240):
    light=practical(name,(x+3,-4,6),(x,0,1),energy,5,(.84,.91,1))
    light.data.use_shadow=False
    return light

def angle_at(f):
    for (a,angle_a,z_a),(b,angle_b,z_b) in zip(pitch_keys,pitch_keys[1:]):
        if a<=f<=b:
            t=(f-a)/(b-a)
            t=t*t*(3-2*t)
            return angle_a+(angle_b-angle_a)*t,z_a+(z_b-z_a)*t
    return pitch_keys[-1][1:]

pitch_keys=[
    (450,13,-1.1),(span(0)[1],29,-1.9),(span(1)[1],66,-3.0),
    (fraction(2,.57),90,-3.45),(span(11)[0],90,-3.45),
    (fraction(11,.58),90,-3.45),(span(11)[1],2,-.2),(end,.5,-.04),
]
for f in range(451,end+1):
    tilt,z=angle_at(f)
    hull.rotation_euler.y=math.radians(-tilt)
    hull.location.z=z
    hull.keyframe_insert("rotation_euler",frame=f)
    hull.keyframe_insert("location",frame=f)
for f in range(468,end+16,9):
    noise.inputs["W"].default_value=.1+(f-1)*.00868
    noise.inputs["W"].keyframe_insert("default_value",frame=f)
    for name,p in (("Swell sine",0),("Swell cosine",math.pi/2)):
        key=sea.data.shape_keys.key_blocks[name]
        key.value=math.cos((f-1)*.064+p)
        key.keyframe_insert("value",frame=f)

def xyz(p,f):
    degrees,z=angle_at(f)
    return tuple(Matrix.Rotation(math.radians(-degrees),3,"Y")@Vector(p)+Vector((0,0,z)))

def follow(f,eye,target,lens):
    return f,xyz(eye,f),xyz(target,f),lens

# Fix the shortest-angle flip between the two approved valve reach poses.
# The archive and renders of TEST_001_V3 remain untouched.
approved_deck=bpy.data.objects["Oddplot • deck station"]
def component_nodes(root,prefix):
    return sorted((o for o in root.children if o.name.startswith(prefix)),key=lambda o:o.name)
forearm=component_nodes(approved_deck,"Flat forearm")[1]
glove_rig=component_nodes(approved_deck,"Hand")[1]
repair=[]
for f in range(92,106):
    scene.frame_set(f)
    delta=glove_rig.location-forearm.location
    repair.append((f,math.atan2(delta.x,delta.z),math.hypot(delta.x,delta.z)))
for f,rotation,length in repair:
    forearm.rotation_euler.y=rotation
    forearm.scale.z=length
    forearm.keyframe_insert("rotation_euler",frame=f,index=1)
    forearm.keyframe_insert("scale",frame=f,index=2)

# Transition sequence on the same hull used in the opening.
a,b=span(0)
cam=shot("05 · Deployment",a,b,[(a,(23,-51,13),(5,0,5.4),29),
                               (b,(22,-49,15),(4,0,6.1),30)],"ocean")
banner(cam,"CONTROLLED DEPLOYMENT","ABOUT 30 MINUTES · TIME COMPRESSED")

deck_set=section("Crew transition equipment",parent=hull)
floor_x=12.65
box("Grated platform that becomes the floor",(floor_x-.06,-1.10,2.71),
    (.12,3.18,2.11),TEAL,deck_set,.012)
for y in (-2.42,-2,-1.58,-1.16,-.74,-.32,.10):
    box("New floor non-slip strip",(floor_x+.007,y,2.72),
        (.016,.026,2.0),CREAM,deck_set,.005)
a,b=span(1)
deck_actor=section("Crew braced on original deck",parent=hull)
middle=(a+b)//2
def positions(a,b,kind):
    m=(a+b)//2
    if kind=="brace":
        return [(a,-.02,.025,-.11,.10,0),(a+28,.028,.06,.045,.19,-.038),(m,.07,.12,.11,.26,-.07),(b,.09,.12,.15,.24,-.055)]
    return [(a,-.03,.02,.07,.22,-.012),(m,.042,.035,-.08,.12,.008),(b,.006,.016,-.13,.08,.003)]

grips=((-0.36,1.17),(.37,1.13))
reach_start=a
def reach(frame,index):
    t=max(0,min(1,(frame-reach_start)/28))
    t=t*t*(3-2*t)
    on_jacket=(-.22 if index==0 else .22,1.00)
    return tuple(start+(finish-start)*t for start,finish in zip(on_jacket,grips[index]))

crew=character(deck_actor,(13.80,-1.19,1.65),"Deployment crew · approved hero",
               positions(a,b,"brace"),frames=range(a,b+1),grips=reach)
for wx,wz in grips:
    x=13.80+wx
    z=1.65+wz
    pipe("Crew handhold",[(x,-.86,z-.24),(x,-1.19,z-.12),(x,-1.19,z+.12),(x,-.86,z+.24)],
         .033,GOLD,deck_actor)
watch=character(deck_actor,(15.21,-.70,1.65),"Second crew member",positions(a,b,"brace"),
                frames=range(a,b+1),grips=reach)
watch.scale=(.86,)*3
# Helmet and jacket colour distinguish the second crew member.
for obj in watch.children_recursive:
    if obj.type=="MESH" and obj.name.startswith("Orange flotation panel"):
        obj.data.materials[0]=GOLD
    if obj.name.startswith("Avatar •"):
        oval("Crew watch cap",.015,.621,.33,.095,-.012,TEAL,obj,-.03)
for wx,wz in grips:
    x,z=15.21+wx*.86,1.65+wz*.86
    pipe("Second crew handhold",[(x,-.44,z-.21),(x,-.70,z-.11),(x,-.70,z+.11),(x,-.44,z+.21)],
         .028,GOLD,deck_actor)
shot("06 · Brace at the handholds",a,b,[
    follow(a,(17.0,-6.8,3.8),(14.24,-.97,2.57),31),
    follow(middle,(17.15,-7.0,3.65),(14.31,-.96,2.56),33),
    follow(b,(17.31,-7.25,3.58),(14.35,-.97,2.56),34)],"ocean",(deck_set,deck_actor))

a,b=span(2)
cut=fraction(2,.57)
shot("07 · The turn reaches vertical",a,cut-1,[
    (a,(16,-49,15),(2.5,0,6.3),32),
    (cut-1,(18,-46,17),(3.3,0,7.5),33)],"ocean",(deck_set,))
new_deck_actor=section("Crew on the former bulkhead",parent=hull)
new_crew=character(new_deck_actor,(floor_x,-1.11,2.55),"Hero · former bulkhead",
                   positions(cut,b,"land"),frames=range(cut,b+1),grips=grips)
new_crew.rotation_euler.y=math.pi/2
for wx,wz in grips:
    x,z=floor_x+wz,2.55-wx
    pipe("New floor handhold",[(x-.24,-.83,z),(x-.11,-1.11,z),(x+.11,-1.11,z),(x+.24,-.83,z)],
         .032,GOLD,new_deck_actor)
cam=shot("08 · The old wall is the floor",cut,b,[
    (cut,(-6.35,-6.45,11.23),(-2.48,-1.10,10.23),34),
    (b,(-5.84,-6.18,11.18),(-2.55,-1.09,10.23),35)],"ocean",(deck_set,new_deck_actor))
banner(cam,"FORMER WALL","NOW THE FLOOR")

# Separate dry quarters, with a bunk mounted on a gimbal on each end.
a,b=span(3)
bunk_set=section("Gimballed bunk demonstration",200)
bunk_box=section("Rotating room",parent=bunk_set)
for f,degree in ((a,-44),(fraction(3,.70),-90),(b,-90)):
    bunk_box.rotation_euler.y=math.radians(degree)
    bunk_box.keyframe_insert("rotation_euler",frame=f)
box("Quarter bulkhead",(0,.63,1),(4,.18,3.7),WALL,bunk_box,.035)
box("Painted lower bulkhead",(0,.52,-.18),(4,.08,1.4),TEAL,bunk_box,.026)
box("Stiffener",(-1.7,.45,1),(0.15,.19,3.55),CREAM,bunk_box,.025)
box("Old deck reference",(0,-.20,-.84),(4,1.7,.13),FLOOR,bunk_box,.025)
box("New deck reference",(-1.93,-.20,1.03),(.14,1.7,3.65),TEAL,bunk_box,.025)
bunk=empty("Empty bunk · pivot keeps bed level",bunk_box,(0,.06,1.05))
for f,degree in ((a,44),(fraction(3,.70),90),(b,90)):
    bunk.rotation_euler.y=math.radians(degree)
    bunk.keyframe_insert("rotation_euler",frame=f)
box("Bunk frame",(0,-.30,-.045),(2.4,.93,.17),DARK,bunk,.048)
box("Cream mattress",(0,-.31,.086),(2.33,.87,.17),CREAM,bunk,.061)
box("Pillow",(-.77,-.31,.194),(.54,.63,.1),FACE,bunk,.047)
box("Folded bedding",(.73,-.31,.192),(.57,.84,.046),TEAL,bunk,.021)
for x in (-1.16,1.16):
    cylinder("Bunk pivot axle",(x,-.65,0),(x,.53,0),.075,GOLD,bunk)
bunk_light=stage_light("Quarters overhead",200,260)
shot("09 · The bunk swivels level",a,b,[
    (a,(201.15,-5.61,2.17),(199.24,-.11,.62),36),
    (b,(200.83,-5.51,2.05),(198.97,-.10,.40),36)],"studio",(bunk_set,),bunk_light)

def copy_tree(root,parent):
    copied=root.copy()
    scene.collection.objects.link(copied)
    copied.parent=parent
    for child in tuple(root.children):
        copy_tree(child,copied)
    return copied

a,b=span(4)
wash_set=section("Dry wash station upright",400)
wash=copy_tree(sink,wash_set)
wash.location=(.02,.22,.97)
wash.rotation_euler=(0,0,0)
box("Reoriented wash floor",(0,-.2,-.12),(5,4.5,.24),FLOOR,wash_set,.04)
box("Reoriented wash bulkhead",(0,.98,1.4),(5,.17,2.8),WALL,wash_set,.03)
box("Enamel stripe",(0,.878,1.03),(5,.045,.54),TEAL,wash_set,.02)
box("Basin pedestal",(.02,.41,.43),(.53,.42,.87),TEAL,wash_set,.045)
pipe("Basin trap",[(.02,.22,.83),(.02,.22,.58),(.02,.38,.51),(.02,.88,.52)],.042,CHROME,wash_set)
wash_light=stage_light("Wash station overhead",400,255)
shot("10 · The sideways sink works upright",a,b,[
    (a,(401.26,-2.92,2.73),(400.06,.17,.85),42),
    (b,(400.84,-2.65,2.48),(400.03,.20,.88),44)],"studio",(wash_set,),wash_light)

# Physical scale diagram, with the same hull profile and observed submerged length.
a,b=span(5)
hull_section=section("Depth illustration",650)
depth=empty("FLIP translated to diagram",hull_section,(0,0,-3.45))
depth.rotation_euler.y=-math.pi/2
for obj in hull.children:
    if obj.name.startswith(("Unpowered hull","Antifouling boot","Rub rail","Occupied forward block",
                            "Bridge roof","Bridge glass","Radio mast","Set-in window frame")):
        copied=obj.copy()
        scene.collection.objects.link(copied)
        copied.parent=depth
for x in (-29,-15,0,15,29):
    box("Depth guide strip",(x,6,-44),(.095,.06,103),material("Faint depth grid","255569",ink=1),hull_section)
for z in (0,-15,-30,-45,-60,-75,-91.45):
    box("Horizontal depth guide",(0,6,z),(61,.065,.12),material("Ocean profile guide","367285",ink=1),hull_section)
layers=[(-94,"112A44"),(-75,"17435D"),(-56,"1A5772"),(-37,"216980"),(-18,"2A8395"),(1,"8CB8BD")]
for i,((z,c),(ceil,_)) in enumerate(zip(layers,layers[1:])):
    box("Water column shade",(0,8,(z+ceil)/2),(150,.15,ceil-z),
        material("Marine depth "+str(i),c,ink=1),hull_section)
box("Profile sky",(0,8,16),(150,.15,30),material("Profile sky mist","AAC6C9",ink=1),hull_section)
pipe("Actual 91 m depth line",[(-11,-4,0),(-9.4,-4,0),(-9.4,-4,-91.45),(-11,-4,-91.45)],
     .18,FACE,hull_section)
depth_light=stage_light("Depth illustration fill",650,450)
depth_light.data.type="SUN"
depth_light.data.energy=1.6
cam=shot("11 · 300 feet below the waterline",a,b,[
    (a,(655,-121,-35),(650,0,-37),34),
    (b,(654,-115,-39),(650,0,-40),34)],"diagram",(hull_section,),depth_light)
banner(cam,"300 FT / 91 M","BELOW THE SURFACE")

# Actual upright FLIP near-surface and name reveal.
a,b=span(6)
shot("12 · The scientists can begin",a,b,[
    (a,(-14,-35,11),(-.5,0,9),37),
    (b,(-12,-31,13),(-.5,0,10),37)],"ocean")
a,b=span(7)
cam=shot("13 · FLIP name reveal",a,b,[
    (a,(-21,-43,17),(-.5,0,7.5),40),
    (b,(-19,-40,14),(-.5,0,8.5),42)],"ocean")
banner(cam,"FLIP","FLOATING RESEARCH PLATFORM")

# Separate ordinary vessel on the same continuous sea, with removable instruments.
a,b=span(8)
merchant=section("Ordinary research vessel")
merchant.location=(0,-105,0)
samples=[(-11,2.2,1.5,-1.8),(-9,3.0,1.65,-1.9),(6.8,3.1,1.80,-1.65),
         (9,2.0,1.94,-1.13),(11,.14,2.2,-.25)]
verts=[]
for x,w,top,bot in samples:
    verts.extend([(x,-w,top),(x,-w,0),(x,-.63*w,bot),(x,.63*w,bot),(x,w,0),(x,w,top)])
faces=[tuple(reversed(range(6)))]
for i in range(len(samples)-1):
    faces.extend((i*6+k,i*6+(k+1)%6,(i+1)*6+(k+1)%6,(i+1)*6+k) for k in range(6))
faces.append(tuple(range(len(verts)-6,len(verts))))
ordinary=mesh("Wide shallow hull",verts,faces,STEEL,merchant)
ordinary.data.materials.append(RUST)
ordinary.data.materials.append(DECK)
for p in ordinary.data.polygons:
    if 0<p.index<len(ordinary.data.polygons)-1:
        side=(p.index-1)%6
        p.material_index=1 if side in (1,2,3) else 2 if side==5 else 0
box("Ship deckhouse",(-3.7,0,2.83),(7.0,4.18,2.11),CREAM,merchant,.11)
box("Ship bridge roof",(-3.7,0,3.97),(7.42,4.45,.21),TEAL,merchant,.06)
for x in (-6,-4.6,-3.2,-1.8):
    box("Bridge window",(x,-2.105,3.11),(1.08,.045,.53),GLASS,merchant,.042)
cylinder("Survey boat antenna",(-3.75,0,4.0),(-3.75,0,6.5),.094,STEEL,merchant)
box("Survey instrument on deck",(3,-.45,2.36),(1.34,.83,1.04),TEAL,merchant,.046)
box("Survey instrument display",(3,-.88,2.50),(.91,.043,.43),GLASS,merchant,.028)
pipe("Survey boat railing",[(-10,-2.80,2.57),(0,-3.06,2.65),(7,-2.96,2.73),(10.85,-.23,3.01)],
     .037,STEEL,merchant)
for f in range(a,b+2,3):
    t=(f-a)/30
    merchant.rotation_euler.x=math.radians(9.8)*math.sin(4.9*t)
    merchant.rotation_euler.y=math.radians(7.8)*math.sin(3.6*t+.55)
    merchant.location.z=.44*math.sin(4.7*t)
    merchant.keyframe_insert("rotation_euler",frame=f)
    merchant.keyframe_insert("location",frame=f)
cam=shot("14 · Pitch and roll of an ordinary ship",a,b,[
    (a,(21,-132,12),(0,-105,2.0),31),
    (b,(19,-132,11),(0,-105,2.2),31)],"comparison",(merchant,))
banner(cam,"ORDINARY SHIP","ROLL + PITCH")

a,b=span(9)
# Paint a narrow, measured response into the upright keys.
for f in range(a,b+1):
    t=(f-a)/30
    hull.rotation_euler.y=-math.pi/2+.010*math.sin(t*3.5)
    hull.rotation_euler.x=.012*math.sin(t*3.5+.4)
    hull.location.z=-3.45+.065*math.sin(t*3.5)
    for prop in ("rotation_euler","location"):
        hull.keyframe_insert(prop,frame=f)
for f in (a-1,b+1):
    hull.rotation_euler.x=0
    hull.keyframe_insert("rotation_euler",frame=f,index=0)
cam=shot("15 · A spar responds much less",a,b,[
    (a,(-16,-38,12),(-.4,0,7.3),38),
    (b,(-13,-35,12),(-.4,0,7.3),38)],"ocean")
banner(cam,"FLIP","REDUCED WAVE MOTION")

# Dry lab and real perspective on the same approved vector character.
a,b=span(10)
lab=section("Upright marine laboratory",850)
box("Laboratory floor",(0,-.3,-.13),(6.4,6,.26),FLOOR,lab,.05)
box("Laboratory back wall",(0,1.23,1.51),(6.4,.21,3.02),WALL,lab,.04)
box("Laboratory lower stripe",(0,1.10,.54),(6.3,.09,.98),TEAL,lab,.035)
box("Ocean window recess",(-1.54,1.09,1.93),(1.71,.12,1.11),DARK,lab,.05)
box("Ocean window",(-1.54,1.011,1.93),(1.53,.039,.94),GLASS,lab,.04)
box("Console stand",(.78,.58,.60),(1.41,.70,1.18),TEAL,lab,.060)
box("Console top",(.79,.56,1.22),(1.65,.9,.11),STEEL,lab,.036)
box("Hydrophone display frame",(.79,.64,1.64),(1.49,.17,.73),DARK,lab,.048)
box("Hydrophone display",(.79,.544,1.64),(1.35,.04,.62),NAVY,lab,.039)
for i in range(5):
    y=1.45+i*.095
    flat_line("Display grid",[(.19,y),(1.39,y)],.004,.516,TEAL,lab)
green=material("Pale cyan instrument phosphor","A8F5EB",ink=1)
trace=empty("Live hydrophone reading",lab)
path=[(.22+i*.024,1.64+(.016+.08*math.exp(-((i-23)/10)**2))*math.sin(i*1.2)) for i in range(48)]
flat_line("Waveform",path,.012,.509,green,trace)
for f in range(a,b+1,8):
    trace.scale.z=.82+.14*math.sin(f*.45)
    trace.location.z=1.64*(1-trace.scale.z)
    trace.keyframe_insert("scale",frame=f)
    trace.keyframe_insert("location",frame=f)
lettering("Hydrophones label","HYDROPHONES",(.25,.515,1.88),.065,green,lab)
for x in (.22,.35,.48,.61):
    cylinder("Console switch",(x,.26,1.277),(x,.26,1.32),.028,GOLD,lab)
lab_hero=character(lab,(-.58,-.18,0),"Hero · lab station",positions(a,b,"land"),
                   indoors=True,frames=range(a,b+1))
lab_hero.rotation_euler.z=.28
lab_light=stage_light("Laboratory top light",850,270)
shot("16 · Listening under the waves",a,b,[
    (a,(851.6,-4.97,2.58),(850.12,.29,1.04),31),
    (b,(851.36,-4.52,2.3),(850.12,.28,1.15),31)],"studio",(lab,),lab_light)

# Readable section view of the documented return cycle.
a,b=span(11)
reverse=fraction(11,.62)
tank_set=section("Ballast air/water section",1050)
tank_water=material("Clear blue ballast water","448EBD",ink=.65)
air=material("Compressed air arrows","FCE6A5",ink=1)
box("Cutaway backdrop",(0,1.18,1.52),(18,.15,14),NAVY,tank_set,.04)
for i,x in enumerate((-.91,0,.91)):
    box("Tank dark inner wall",(x,.36,1.30),(.76,.10,1.69),DARK,tank_set,.031)
    for z in (.44,2.18):
        box("Tank edge",(x,.09,z),(.87,.65,.08),STEEL,tank_set,.025)
    for side in (-1,1):
        box("Tank divider",(x+side*.397,.10,1.31),(.08,.66,1.72),STEEL,tank_set,.018)
    liquid=box("Falling water line",(x,-.13,.49),(.722,.42,1.55),tank_water,tank_set,.018)
    # Animate about the tank floor by offsetting the mesh origin.
    if liquid.type=="MESH":
        for v in liquid.data.vertices:
            v.co.z+=.775
    for f,h in ((a,1),(fraction(11,.20),.96),(fraction(11,.43),.47),(reverse-1,.06)):
        liquid.scale.z=h
        liquid.keyframe_insert("scale",frame=f)
    pipe("Air line",[(x,.10,2.14),(x,.10,2.66),(0,.10,2.66)],.035,GOLD,tank_set)
    for j in range(3):
        z=1.72-.19*j
        arrow=empty("Compressed air moving down",tank_set,(x,-.40,z))
        flat_line("Air arrow stem",[(0,.13),(0,0)],.018,0,air,arrow)
        xy("Air arrow point",[(-.055,.025),(.055,.025),(0,-.043)],-.002,air,arrow)
        for f in range(a,reverse,5):
            arrow.location.z=z-.075*math.sin((f-a)*.23+j)
            arrow.keyframe_insert("location",frame=f)
    pipe("Water discharge line",[(x,.13,.44),(x,.06,.23),(x+.22,-.16,.23)],.043,TEAL,tank_set)
lettering("Air caption","COMPRESSED AIR",(-.74,-.30,2.9),.145,air,tank_set)
lettering("Water caption","BALLAST WATER OUT",(-.72,-.30,.16),.12,FACE,tank_set)
tank_light=stage_light("Ballast cutaway lighting",1050,245)
shot("17 · Compressed air displaces ballast",a,reverse-1,[
    (a,(1050.6,-6.75,2.9),(1050,.1,1.4),36),
    (reverse-1,(1050.45,-6.35,2.9),(1050,.1,1.4),36)],"studio",(tank_set,),tank_light)
shot("18 · FLIP returns to horizontal",reverse,b,[
    (reverse,(-9,-48,13),(-.6,0,7.3),28),
    ((reverse+b)//2,(14,-54,15),(3,0,5.9),29),
    (b,(35,-67,19),(-13,0,3.3),27)],"ocean")
a,b=span(12)
cam=shot("19 · Laboratory at sea",a,b,[
    (a,(22,-44,12),(6,0,3.4),29),
    (b,(28,-51,14),(3,0,3.2),29)],"ocean")
banner(cam,"FLIP","A LABORATORY AT SEA")
recall=copy_tree(card,cam)
recall.animation_data_clear()
recall.rotation_euler.x=-math.pi/2
recall.scale=(.37,)*3
for f,x in ((a,2.0),(fraction(12,.65),2.0),(fraction(12,.77),.22),(b,.22)):
    recall.location=(x,.31,-2.0)
    recall.keyframe_insert("location",frame=f)
for obj in list(recall.children):
    if obj.name.startswith(("Calling expression","Phone by ear","Phone screen edge","Fingers around phone","Call signal")):
        obj.hide_render=True
flat_line("Witness smile",[(.047,-.071),(.077,-.091),(.106,-.090),(.135,-.058)],
          .010,-.042,INK,recall)


all_groups=[deck_set,deck_actor,new_deck_actor,bunk_set,wash_set,hull_section,merchant,lab,tank_set]
def isolate(root, name, excluded=()):
    collection=bpy.data.collections.new(name)
    scene.collection.children.link(collection)
    blocked={obj for group in excluded for obj in [group,*group.children_recursive]}
    for obj in [root,*root.children_recursive]:
        if obj in blocked:
            continue
        for old in list(obj.users_collection):
            old.objects.unlink(obj)
        collection.objects.link(obj)
    return collection


isolate(hull,"Set · original hull",[*all_groups,approved_deck])
isolate(approved_deck,"Set · approved deck actor")
isolate(room,"Set · approved cabin")
for group in all_groups:
    isolate(group,group.name)
for cam in (obj for obj in list(scene.objects) if obj.type=="CAMERA"):
    isolate(cam,"Camera · "+cam.name)
for obj in list(scene.objects):
    if obj.name.startswith(("Near ocean","Far ocean","Broken aft foam")):
        group="Set · far ocean" if obj.name.startswith("Far ocean") else "Set · water surface"
        collection=bpy.data.collections.get(group)
        if not collection:
            collection=bpy.data.collections.new(group)
            scene.collection.children.link(collection)
        for old in list(obj.users_collection):
            old.objects.unlink(obj)
        collection.objects.link(obj)
scene["episode_collections"]=json.dumps([c.name for c in scene.collection.children])
opening=[
    {"name":c1.name,"first":1,"last":165,"mode":"opening-exterior","groups":[],"light":None},
    {"name":c2.name,"first":166,"last":261,"mode":"opening-exterior","groups":[],"light":None},
    {"name":c3.name,"first":262,"last":336,"mode":"opening-cabin","groups":[],"light":None},
    {"name":c4.name,"first":337,"last":450,"mode":"opening-cabin","groups":[],"light":None},
]
scene["episode_groups"]=json.dumps([obj.name for obj in all_groups])
scene["episode_shots"]=json.dumps(opening+shots)
scene["last_frame"]=end
scene["physical_continuity"]="Approved opening plus grounded crew stations. All edited frames use the same 30 fps clock."
scene.frame_set(1)
bpy.context.preferences.filepaths.save_version=0
bpy.ops.wm.save_as_mainfile(filepath=str(SOURCE.parent/"EPISODE_001_SCENE.blend"))
