#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$(realpath "$0")")/.."
tools_dir=${ODDPLOT_TOOLS:-/workspace/oddplot-tools}
python_bin=${ODDPLOT_PYTHON:-$tools_dir/venv/bin/python}
export XDG_CACHE_HOME="${XDG_CACHE_HOME:-$tools_dir/cache}"
export ODDPLOT_RENDER_THREADS="${ODDPLOT_RENDER_THREADS:-4}"
export LP_NUM_THREADS="$ODDPLOT_RENDER_THREADS"
mkdir -p "$XDG_CACHE_HOME"
case "${1:---final}" in
    --preview) export_width=540; export_height=960 ;;
    --final)
        export_width=1080; export_height=1920
        export ODDPLOT_EEVEE_SAMPLES="${ODDPLOT_EEVEE_SAMPLES:-2}"
        ;;
    *) echo "Usage: source/render.sh [--preview|--final]" >&2; exit 2 ;;
esac
frames=$(mktemp -d "${ODDPLOT_FRAMES_PARENT:-/tmp}/oddplot-frames.XXXXXX")
printf 'Rendered frames and logs will be written to %s\n' "$frames"
test -s TEST_001_V3_VOICEOVER.wav
test -s TEST_001_V3_SUBTITLES.srt
"$python_bin" source/mix.py "$frames/MIX.wav"
blender -b -t "$ODDPLOT_RENDER_THREADS" --python-exit-code 1 -P source/scene.py
blender -b TEST_001_V3_SCENE.blend -t "$ODDPLOT_RENDER_THREADS" --python-exit-code 1 -P source/check_motion.py
size="import bpy; r=bpy.context.scene.render; r.resolution_x=$export_width; r.resolution_y=$export_height"
for shots in '1 261' '262 450'; do
    read -r first last <<< "$shots"
    engine_args=()
    if [[ $first == 262 ]]; then
        engine_args=(-P source/cabin_render.py)
    fi
    blender -b TEST_001_V3_SCENE.blend -t "$ODDPLOT_RENDER_THREADS" -E BLENDER_EEVEE_NEXT \
        --python-exit-code 1 --python-expr "$size" "${engine_args[@]}" \
        -s "$first" -e "$last" -o "$frames/f_" -a > "$frames/render-$first.log" 2>&1
done
bash source/encode.sh "$frames" "$frames/MIX.wav"
python3 source/verify.py
