#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$(realpath "$0")")/.."
frames=$(realpath "${1:?Provide native episode JPEG frames}")
mix=$(realpath "${2:?Provide the episode mix WAV}")
last=$(python3 -c 'import json; print(json.load(open("source/edit.json"))[-1]["last"])')
duration=$(awk -v frames="$last" "BEGIN {printf \"%.9f\", frames/30}")
for ((i=1; i<=last; i++)); do
    printf -v file 'f_%04d.jpg' "$i"
    test -s "$frames/$file"
done
export XDG_CACHE_HOME=${XDG_CACHE_HOME:-/workspace/oddplot-tools/cache}
captions="FontName=DejaVu Sans,FontSize=13,Bold=1,PrimaryColour=&H00FFFFFF,OutlineColour=&H0010131C,BorderStyle=1,Outline=1.34,Shadow=0,Alignment=2,MarginV=42"
staging=$(mktemp -d .encode.XXXXXX)
trap 'rm -rf -- "$staging"' EXIT
ffmpeg -hide_banner -loglevel error -xerror -threads 2 \
    -framerate 30 -start_number 1 -i "$frames/f_%04d.jpg" -i "$mix" \
    -filter_threads 2 \
    -vf "scale=1080:1920:out_color_matrix=bt709:out_range=tv,format=yuv420p,subtitles=EPISODE_001_SUBTITLES.srt:force_style='$captions'" \
    -map 0:v:0 -map 1:a:0 -t "$duration" -r 30 \
    -c:v libx264 -threads 3 -preset medium -crf 16 -pix_fmt yuv420p \
    -color_range tv -colorspace bt709 -color_trc bt709 -color_primaries bt709 \
    -c:a aac -ar 48000 -b:a 192k -movflags +faststart "$staging/EPISODE_001.mp4"
mv "$staging/EPISODE_001.mp4" EPISODE_001.mp4
