"""Keep off-set geometry out of the Eevee cabin render."""
import bpy

scene = bpy.context.scene
for name in ("FLIP • pitch pivot near forward end", "Witness phone call • camera-space inset"):
    for obj in bpy.data.objects[name].children_recursive:
        obj.hide_render = True
for obj in scene.objects:
    if obj.name.startswith("Broken aft foam") or obj.name.startswith("Near ocean"):
        obj.hide_render = True
bpy.data.lights["Warm low sun"].energy = 0
bpy.data.lights["Cool off-axis interior fill"].use_shadow = False
bpy.data.lights["Warm window bounce"].use_shadow = False
scene.eevee.shadow_pool_size = "128"
scene.eevee.shadow_step_count = 3
