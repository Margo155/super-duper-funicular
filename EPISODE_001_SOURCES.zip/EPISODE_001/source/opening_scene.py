"""Build the editable Oddplot test in Blender 4.3 using only native materials."""
import math
import os
from pathlib import Path
import random

import bpy
from mathutils import Matrix, Vector

OUT = Path(__file__).resolve().parents[1]
TAU = math.tau
FPS = 30
CUTS = (1, 166, 262, 337)
bpy.ops.wm.read_factory_settings(use_empty=True)
scene = bpy.context.scene


def linear(v):
    return v / 12.92 if v < 0.04045 else ((v + .055) / 1.055) ** 2.4


def rgb(h):
    h = h.strip("#")
    return tuple(linear(int(h[i:i + 2], 16) / 255) for i in (0, 2, 4))


def material(name, hexcode, rough=.55, metal=0, ink=0):
    color = rgb(hexcode)
    m = bpy.data.materials.new(name)
    m.diffuse_color = (*color, 1)
    m.use_nodes = True
    shader = m.node_tree.nodes.get("Principled BSDF")
    shader.inputs["Base Color"].default_value = (*color, 1)
    shader.inputs["Roughness"].default_value = rough
    shader.inputs["Metallic"].default_value = metal
    shader.inputs["Emission Color"].default_value = (*color, 1)
    shader.inputs["Emission Strength"].default_value = ink
    if ink >= 1:
        shader = m.node_tree.nodes.new("ShaderNodeEmission")
        shader.inputs["Color"].default_value = (*color, 1)
        m.node_tree.links.new(shader.outputs[0], m.node_tree.nodes.get("Material Output").inputs[0])
    return m


NAVY = material("Oddplot • midnight navy", "101A32", ink=1)
INK = material("Cel outline", "080D1B", ink=1)
HAIR = material("Hero • blue-black hair", "11182A", ink=1)
RIM = material("Hero • swept slate highlight", "505C83", ink=1)
FACE = material("Hero • warm ivory", "FFF8E9", ink=1)
ORANGE = material("Oddplot • tangerine", "FF870D", ink=1)
ORANGE_SHADE = material("Cel orange in shade", "D95816", ink=1)
REFLECT = material("Life jacket reflective panels", "FFE3A6", ink=1)
STEEL = material("Painted warm-gray maritime steel", "ABB6B1", .58, .1, .13)
TEAL = material("Painted blue steel", "3E6470", ink=.19)
CREAM = material("Satin ivory enamel", "E5D7B2", .53, .03, .11)
DECK = material("Nonskid blue-gray deck", "65787E", .84, ink=.16)
DARK = material("Graphite rubber and seams", "273A43", ink=.14)
RUST = material("Red-orange antifouling", "AE4B29", ink=.16)
RED = material("Safety orange paint", "E47A35", .43, .05, .15)
GOLD = material("Brass hardware", "BC884E", .34, .31, .14)
GLASS = material("Deep blue marine glazing", "367886", .29, .12, .6)
CHROME = material("Brushed chrome", "B6C8C9", .29, .55, .23)
CERAMIC = material("Ivory porcelain", "E6DCC3", .36, .03, .10)
FLOOR = material("Deep mottled linoleum", "426369", .75, ink=.3)
WALL = material("Cream painted bulkhead", "A5B1A5", .84, ink=.16)


def mesh(name, verts, faces, mat=None, parent=None, location=(0, 0, 0)):
    data = bpy.data.meshes.new(name)
    data.from_pydata(verts, [], faces)
    data.update()
    obj = bpy.data.objects.new(name, data)
    scene.collection.objects.link(obj)
    obj.parent = parent
    obj.location = location
    if mat:
        data.materials.append(mat)
    return obj


def empty(name, parent=None, location=(0, 0, 0)):
    obj = bpy.data.objects.new(name, None)
    scene.collection.objects.link(obj)
    obj.parent = parent
    obj.location = location
    return obj


def bevel(obj, size, segments=2):
    if size:
        mod = obj.modifiers.new("Machined edges", "BEVEL")
        mod.width, mod.segments = size, segments
        mod = obj.modifiers.new("Weighted corners", "WEIGHTED_NORMAL")
        mod.keep_sharp = True
    return obj


def box(name, location, size, mat, parent=None, edge=0):
    x, y, z = [s / 2 for s in size]
    verts = [(-x,-y,-z),(x,-y,-z),(x,y,-z),(-x,y,-z),
             (-x,-y,z),(x,-y,z),(x,y,z),(-x,y,z)]
    faces = [(3,2,1,0),(4,5,6,7),(0,1,5,4),(1,2,6,5),(2,3,7,6),(3,0,4,7)]
    return bevel(mesh(name, verts, faces, mat, parent, location), edge)


def cylinder(name, a, b, radius, mat, parent=None, sides=12):
    delta = Vector(b) - Vector(a)
    verts = [(radius*math.cos(TAU*i/sides), radius*math.sin(TAU*i/sides), z)
             for z in (-delta.length/2, delta.length/2) for i in range(sides)]
    faces = [tuple(reversed(range(sides))), tuple(range(sides, sides*2))]
    faces += [(i,(i+1)%sides,(i+1)%sides+sides,i+sides) for i in range(sides)]
    obj = mesh(name, verts, faces, mat, parent, (Vector(a) + Vector(b))/2)
    obj.rotation_euler = delta.to_track_quat("Z", "Y").to_euler()
    for p in list(obj.data.polygons)[2:]:
        p.use_smooth = True
    return obj


def pipe(name, points, radius, mat, parent=None, closed=False):
    data = bpy.data.curves.new(name, "CURVE")
    data.dimensions = "3D"
    data.resolution_u = 1
    data.bevel_depth = radius
    data.bevel_resolution = 2
    spline = data.splines.new("POLY")
    spline.points.add(len(points)-1)
    for p, xyz in zip(spline.points, points):
        p.co = (*xyz, 1)
    spline.use_cyclic_u = closed
    obj = bpy.data.objects.new(name, data)
    scene.collection.objects.link(obj)
    obj.parent = parent
    data.materials.append(mat)
    return obj


def lettering(name, body, loc, size, mat, parent, rot=(math.pi/2, 0, 0)):
    d = bpy.data.curves.new(name, "FONT")
    d.body, d.size, d.align_x, d.align_y = body, size, "CENTER", "CENTER"
    d.space_character = 1.10
    obj = bpy.data.objects.new(name, d)
    scene.collection.objects.link(obj)
    obj.parent = parent
    obj.location, obj.rotation_euler = loc, rot
    d.materials.append(mat)
    return obj


def xy(name, pts, y, mat, parent):
    return mesh(name, [(x,y,z) for x,z in pts], [tuple(range(len(pts)))], mat, parent)


def ellipse_pts(cx, cz, rx, rz, turn=0, sides=48):
    c, s = math.cos(turn), math.sin(turn)
    pts = [(rx*math.cos(TAU*i/sides), rz*math.sin(TAU*i/sides)) for i in range(sides)]
    return [(cx+x*c-z*s, cz+x*s+z*c) for x,z in pts]


def oval(name, cx, cz, rx, rz, y, mat, parent, turn=0):
    return xy(name, ellipse_pts(cx, cz, rx, rz, turn), y, mat, parent)


def bezier(points, steps=12):
    values = [points[0]]
    for i in range(1, len(points), 3):
        a, b, c, d = values[-1], *points[i:i+3]
        for j in range(1, steps + 1):
            t = j/steps
            k = 1-t
            values.append(tuple(k**3*p + 3*k*k*t*q + 3*k*t*t*r + t**3*s
                                for p,q,r,s in zip(a,b,c,d)))
    return values


def flat_line(name, pts, radius, y, mat, parent):
    # For repeated animated strokes, use one planar mesh including the end caps.
    v, f = [], []
    def append(face):
        f.append(tuple(range(len(v),len(v)+len(face))))
        v.extend((x,y,z) for x,z in face)
    for a,b in zip(pts,pts[1:]):
        delta = Vector((b[0]-a[0],b[1]-a[1])).normalized()
        n = radius*Vector((-delta.y,delta.x))
        append([Vector(a)+n,Vector(b)+n,Vector(b)-n,Vector(a)-n])
    for x,z in pts:
        append(ellipse_pts(x,z,radius,radius,sides=14))
    return mesh(name,v,f,mat,parent)


def practical(name, loc, target, energy, size, color):
    d = bpy.data.lights.new(name, "AREA")
    d.energy, d.shape, d.size, d.color = energy, "DISK", size, color
    obj = bpy.data.objects.new(name, d)
    scene.collection.objects.link(obj)
    obj.location = loc
    obj.rotation_euler = (Vector(target)-obj.location).to_track_quat("-Z","Y").to_euler()
    return obj


# Animated ocean, fixed horizon and a hazy light gradient.
world = bpy.data.worlds.new("Late afternoon maritime haze")
scene.world = world
world.use_nodes = True
wn, wl = world.node_tree.nodes, world.node_tree.links
bg = wn.get("Background")
coords = wn.new("ShaderNodeTexCoord")
sep = wn.new("ShaderNodeSeparateXYZ")
wl.new(coords.outputs["Normal"], sep.inputs[0])
height = wn.new("ShaderNodeMapRange")
height.inputs["From Min"].default_value = -.46
height.inputs["From Max"].default_value = 0
wl.new(sep.outputs["Z"], height.inputs[0])
sky = wn.new("ShaderNodeValToRGB")
sky.color_ramp.elements[0].color = (*rgb("457898"),1)
sky.color_ramp.elements[1].color = (*rgb("DBE3D1"),1)
sky.color_ramp.elements.new(.82).color = (*rgb("8EBFCE"),1)
wl.new(height.outputs[0], sky.inputs[0])
wl.new(sky.outputs[0], bg.inputs["Color"])
bg.inputs["Strength"].default_value = .80
sun_d = bpy.data.lights.new("Warm low sun", "SUN")
sun = bpy.data.objects.new(sun_d.name, sun_d)
scene.collection.objects.link(sun)
sun.rotation_euler = Vector((.65,.37,-.73)).to_track_quat("-Z","Y").to_euler()
sun_d.energy, sun_d.angle, sun_d.color = 2.15, math.radians(3), (1,.82,.62)

water = material("Animated ink-blue sea and broken glints", "23718D", .48, .06)
n, l = water.node_tree.nodes, water.node_tree.links
shader = n.get("Principled BSDF")
geometry = n.new("ShaderNodeNewGeometry")
mapping = n.new("ShaderNodeVectorMath")
mapping.operation = "MULTIPLY"
mapping.inputs[1].default_value = (.31,.61,.3)
l.new(geometry.outputs["Position"],mapping.inputs[0])
noise = n.new("ShaderNodeTexNoise")
noise.noise_dimensions = "4D"
noise.inputs["Scale"].default_value = 1.2
noise.inputs["Detail"].default_value = 1.0
l.new(mapping.outputs[0],noise.inputs["Vector"])
for f,t in ((1,.1),(450,4)):
    noise.inputs["W"].default_value=t
    noise.inputs["W"].keyframe_insert("default_value",frame=f)
ramp = n.new("ShaderNodeValToRGB")
for el, pos, col in zip(ramp.color_ramp.elements,(.18,.8),("12547C","71C5C7")):
    el.position,el.color=pos,(*rgb(col),1)
for p,c in ((.46,"206987"),(.63,"3A91A3"),(.735,"5DB4B7")):
    ramp.color_ramp.elements.new(p).color=(*rgb(c),1)
l.new(noise.outputs["Fac"],ramp.inputs[0])
l.new(ramp.outputs[0],shader.inputs["Base Color"])
l.new(ramp.outputs[0],shader.inputs["Emission Color"])
shader.inputs["Emission Strength"].default_value=.78
shader.inputs["Specular IOR Level"].default_value=.14
bump=n.new("ShaderNodeBump")
bump.inputs["Strength"].default_value=.13
bump.inputs["Distance"].default_value=.22
l.new(noise.outputs["Fac"],bump.inputs["Height"])
l.new(bump.outputs[0],shader.inputs["Normal"])
# The near patch has keyed wave geometry. Beyond it the same shader continues to the horizon.
size=150
dim=73
verts=[(-size + 2*size*i/(dim-1),-size + 2*size*j/(dim-1),0)
       for j in range(dim) for i in range(dim)]
faces=[(j*dim+i,j*dim+i+1,(j+1)*dim+i+1,(j+1)*dim+i)
       for j in range(dim-1) for i in range(dim-1)]
sea=mesh("Near ocean • moving wave surface",verts,faces,water)
for poly in sea.data.polygons:
    poly.use_smooth=True
sea.shape_key_add(name="Mean surface")
for name,phase in (("Swell sine",0),("Swell cosine",math.pi/2)):
    key=sea.shape_key_add(name=name)
    key.slider_min=-1
    for p,(x,y,_) in zip(key.data,verts):
        fade=min(1,max(0,(size-max(abs(x),abs(y)))/15))
        p.co.z=fade*(.14*math.sin(.24*x+.22*y+phase)+.09*math.sin(-.39*x+.47*y+phase))
    for frame in range(1,451,9):
        key.value=math.cos((frame-1)*.064+phase)
        key.keyframe_insert("value",frame=frame)
edge=8400
far_verts=[(-edge,-edge,0),(edge,-edge,0),(edge,edge,0),(-edge,edge,0),
           (-size,-size,0),(size,-size,0),(size,size,0),(-size,size,0)]
mesh("Far ocean • level horizon",far_verts,[(0,1,5,4),(1,2,6,5),(2,3,7,6),(3,0,4,7)],water)

# Forward occupied end is +X. The floodable spar and the dry accommodation are separate.
hull=empty("FLIP • pitch pivot near forward end")
hull["geometry"] = "108 m overall. Forward end +X; approximately 91 m spar at stern."
hull["ballast"] = "Sea water enters internal aft ballast compartments. Accommodation remains dry."
sections=[(-88,.34,1.22,-1.55),(-85,1.48,1.38,-1.84),(-77,1.80,1.42,-1.88),
          (-60,1.82,1.45,-1.89),(-26,1.82,1.47,-1.9),(-5,1.94,1.51,-1.94),
          (1,3.0,1.65,-1.94),(12,3.06,1.65,-1.71),(18,2.1,1.65,-1.12),(20.3,.16,1.76,-.5)]
verts=[]
for x,w,top,bot in sections:
    verts.extend([(x,-w,top),(x,-w,0),(x,-.72*w,bot),(x,.72*w,bot),(x,w,0),(x,w,top)])
faces=[tuple(reversed(range(6)))]
for i in range(len(sections)-1):
    faces += [(i*6+k,i*6+(k+1)%6,(i+1)*6+(k+1)%6,(i+1)*6+k) for k in range(6)]
faces.append(tuple(range(len(verts)-6,len(verts))))
body=mesh("Unpowered hull • continuous long tapered spar",verts,faces,STEEL,hull)
body.data.materials.append(RUST)
body.data.materials.append(DECK)
for p in body.data.polygons:
    if 0 < p.index < len(body.data.polygons)-1:
        k=(p.index-1)%6
        p.material_index=1 if k in (1,2,3) else (2 if k==5 else 0)

for ysign in (-1,1):
    pipe("Antifouling boot stripe",[(x,ysign*w*1.001,.13) for x,w,_,_ in sections],.07,DARK,hull)
    pipe("Rub rail and sheer edge",[(x,ysign*w*1.001,top-.12) for x,w,top,_ in sections],.068,TEAL,hull)
    for x in (-76,-55,-36,-17,-6):
        box("Spar inspection hatch", (x,ysign*.44,1.50),(.88,.64,.13),CREAM,hull,.045)
    for x in (4,8,12):
        oval("Dark marine port",x,.92,.24,.13,ysign*3.065,DARK,hull)
for x in range(-82,-4,5):
    box("Spar reinforcement", (x,0,1.49),(.22,3.56,.09),TEAL,hull)
for i,x in enumerate((-80,-70,-60,-50,-40,-30,-20,-10)):
    tank=empty(f"Ballast compartment {i+1:02d} • in spar",hull,(x,0,-.20))
    shell=box("Isolated ballast shell", (0,0,0),(8.6,2.39,2.3),TEAL,tank,.16)
    shell.display_type="WIRE"
    shell.hide_render=True  # opaque hull remains intact in the narrative views
    fill=box("Sea water in ballast", (0,0,-.59),(8.15,2.08,1.0),water,tank)
    fill.hide_render=True
    for frame,h in ((1,.09),(120,.38),(261,.75),(450,.90)):
        fill.scale.z=h*(1-i*.043)
        fill.location.z=-1.0+.5*fill.scale.z
        fill.keyframe_insert("scale",frame=frame)
        fill.keyframe_insert("location",frame=frame)
box("Occupied forward block", (6.7,0,2.88),(8.3,4.28,2.46),CREAM,hull,.13)
box("Bridge skirt", (6.7,0,2.23),(8.42,4.4,.26),TEAL,hull,.04)
box("Bridge roof", (6.9,0,4.16),(8.95,4.63,.27),STEEL,hull,.08)
for x in (3.5,4.75,6.00,7.25,8.50,9.75):
    for ysign in (-1,1):
        box("Set-in window frame", (x,ysign*2.149,3.22),(1.08,.12,.68),DARK,hull,.06)
        box("Bridge glass", (x,ysign*2.212,3.22),(.94,.035,.52),GLASS,hull,.042)
        box("Glazing divider", (x,ysign*2.235,3.22),(.043,.017,.53),CREAM,hull)
for y in (-1.2,0,1.2):
    box("Forward glazing frame", (10.86,y,3.26),(.13,1.02,.77),DARK,hull,.075)
    box("Forward bridge glass", (10.934,y,3.26),(.045,.89,.59),GLASS,hull,.060)
box("Machinery box", (1.9,0,2.15),(1.85,3.1,1.0),TEAL,hull,.10)
box("Vent bank", (2.6,-1.58,2.36),(.9,.08,.51),DARK,hull,.04)
for z in (2.2,2.29,2.38,2.47):
    box("Vent louver", (2.6,-1.63,z),(.85,.04,.026),STEEL,hull)
cylinder("Radio mast",(7,0,4.25),(7,0,7.1),.095,TEAL,hull)
cylinder("Signal yard",(7,-1.25,6.44),(7,1.25,6.44),.038,STEEL,hull)
for y in (-.94,.94):
    cylinder("Mast stay",(7,y,4.32),(7,0,6.65),.018,DARK,hull)
    cylinder("Navigation lamp",(7,y,6.46),(7,y,6.64),.094,RED,hull)
pipe("Scientific boom", [(4.8,0,4.3),(3.0,0,5.9),(1.7,0,5.9)],.065,GOLD,hull)
pipe("Boom cable", [(1.7,0,5.91),(.5,0,2.2)],.024,DARK,hull)

def rails(points,z=1.65):
    for x,y in points:
        cylinder("Rail stanchion",(x,y,z),(x,y,z+.94),.044,TEAL,hull)
        cylinder("Stanchion flange",(x,y,z),(x,y,z+.043),.09,DARK,hull)
    for h in (.34,.91):
        pipe("Continuous rail",[(x,y,z+h) for x,y in points],.034,STEEL,hull)

rails([(-5,-1.7),(0,-2.25),(2,-2.86),(5,-2.88),(8,-2.88),(11.9,-2.88)])
rails([(16.7,-2.59),(18,-1.88),(19.8,-.44),(19.8,.44),(18,1.88),
       (15,2.68),(12,2.88),(9,2.88),(6,2.88),(3,2.86),(0,2.25),(-5,1.7)])
rails([(-74,1.70),(-66,1.70),(-56,1.70),(-46,1.70),(-36,1.70),(-26,1.70),(-16,1.70)],1.48)
for j in range(5):
    box("Painted safe working zone", (12+j*1.14,-1.94,1.656),(.71,.048,.009),CREAM,hull)
for x in (11.75,16.85):
    box("Deck hatch", (x,.46,1.667),(.89,1.03,.08),TEAL,hull,.046)
    for y in (.13,.79):
        cylinder("Hatch hinge", (x-.40,y,1.74),(x-.20,y,1.74),.035,STEEL,hull)
pipe("Valve to internal ballast manifold",[(14.63,-.84,1.70),(14.63,-.84,2.13),(14.34,-.84,2.13),
                                           (14.19,-.84,1.85),(12.4,-.84,1.85)],.084,TEAL,hull)
valve=empty("Ballast valve • hand wheel",hull,(14.65,-.92,2.24))
cylinder("Valve shaft",(0,.15,0),(0,-.16,0),.079,GOLD,valve)
box("Valve plinth",(14.63,-.84,1.75),(.38,.30,.19),DARK,hull,.033)
pipe("Orange handwheel",[(.235*math.cos(TAU*i/44),-.19,.235*math.sin(TAU*i/44))
                         for i in range(44)],.037,RED,valve,closed=True)
for i in range(5):
    a=TAU*i/5
    cylinder("Cast wheel spoke",(0,-.19,0),(.227*math.cos(a),-.19,.227*math.sin(a)),.022,RED,valve)
def wheel_rotation(f):
    progress = min(1, max(0, (f - 111) / 33))
    return -.05 - 1.45 * progress**2 * (3 - 2 * progress)


for f in (1, *range(105, 152), 450):
    turn = wheel_rotation(f)
    valve.rotation_euler.y=turn
    valve.keyframe_insert("rotation_euler",frame=f)

def hull_pose(f):
    stops=((1,.57,-.06),(55,1.3,-.18),(165,4.2,-.42),(261,12.0,-.92),(450,13.0,-1.10))
    for (a,aa,az),(b,ba,bz) in zip(stops,stops[1:]):
        if f<=b:
            t=(f-a)/(b-a)
            return math.radians(-(aa+(ba-aa)*t)),az+(bz-az)*t
    return math.radians(-13.0),-1.10

for f in (1,55,165,261,450):
    theta,z=hull_pose(f)
    hull.rotation_euler.y,hull.location.z=theta,z
    hull.keyframe_insert("rotation_euler",frame=f)
    hull.keyframe_insert("location",frame=f)

# Animated broken water streaks at the aft waterline. Every strip is world-space, not hull-parented.
foam=[material("Foam thin", "84C8CB", ink=1),material("Foam peak", "BEDEDA", ink=1)]
rng=random.Random(2601)
for i in range(44):
    x=rng.uniform(-86,-7)
    y=rng.choice((-1,1))*rng.uniform(1.80,4.30)
    length=rng.uniform(.15,1.25)
    w=rng.uniform(.035,.13)
    obj=mesh("Broken aft foam",[(0,0,0),(length*.2,w,0),(length*.76,w*.58,0),
                               (length,0,0),(length*.69,-w*.58,0),(length*.12,-w*.46,0)],
             [(0,1,2,3,4,5)],foam[i%2],location=(x,y,.21))
    for f in (1,55,105,165,210,261,450):
        obj.location.x=x-.013*f
        obj.location.y=y+.22*math.sin(i+f*.032)
        obj.location.z=.20+.026*math.sin(i+f*.054)
        obj.scale.x=max(.10,(.65+.35*math.sin(i+f*.073))*(.75 if f>180 and x < -52 else 1))
        obj.keyframe_insert("location",frame=f)
        obj.keyframe_insert("scale",frame=f)

# Character artwork traced as planar vector shapes from the avatar supplied in chat.
# The cutout excludes the logo ring, hands from the icon pose, and the backdrop.
def head_rig(parent):
    head=empty("Avatar • rigged face and swept hair",parent,(0,0,1.38))
    k=.00137
    def uv(px,py):
        return ((px-621)*k,(907-py)*k)
    def path(name, coords, depth, mat):
        return xy(name,bezier([uv(*p) for p in coords]),depth,mat,head)
    def feature(name,x,y,rx,rz,depth,mat,angle=0,anchor=head):
        cx,cz=uv(x,y)
        if anchor!=head:
            return oval(name,0,0,rx*k,rz*k,depth,mat,anchor,angle)
        return oval(name,cx,cz,rx*k,rz*k,depth,mat,head,angle)
    feature("Left ear outline",388,782,72,68,-.001,INK,-.28)
    feature("Left ear ivory",389,782,57,52,-.002,FACE,-.29)
    feature("Right ear outline",865,676,67,75,-.001,INK,.27)
    feature("Right ear ivory",866,677,50,56,-.002,FACE,.28)
    path("Face outline",[(599,419),(740,375),(844,485),(867,624),
                       (898,797),(784,906),(646,909),
                       (511,915),(391,841),(387,687),
                       (372,565),(455,449),(599,419)],-.003,INK)
    path("Ivory face",[(605,434),(731,400),(825,500),(850,630),
                      (883,782),(777,891),(642,892),
                      (515,899),(405,829),(414,678),
                      (417,563),(476,463),(605,434)],-.004,FACE)
    path("Signature side-swept silhouette",[(273,653),(253,651),(258,552),(335,518),
         (355,505),(365,502),(371,502),(345,471),(365,430),(394,404),
         (381,431),(373,459),(383,487),(429,370),(530,331),(621,348),
         (691,358),(741,378),(775,305),(791,309),(804,386),(759,444),
         (674,554),(568,584),(501,580),(489,577),(511,559),(516,544),
         (484,571),(458,584),(432,585),(406,642),(408,705),(434,761),
         (407,770),(368,727),(336,719),(310,697),(294,663),(299,627),
         (284,637),(278,653),(273,653)],-.008,INK)
    path("Blue-black hair fill",[(280,621),(290,555),(330,520),(379,504),
         (364,474),(367,447),(383,425),(376,452),(372,464),(380,493),
         (425,390),(512,347),(607,352),(680,356),(731,386),(766,322),
         (760,451),(649,537),(522,564),(546,525),(555,491),(556,469),
         (508,516),(440,576),(381,581),(364,591),(399,593),(415,589),
         (394,647),(392,696),(390,728),(344,709),(305,649),(333,574),
         (316,575),(292,603),(280,621)],-.009,HAIR)
    path("Swept slate rim",[(393,489),(423,391),(505,340),(585,345),
         (663,349),(715,386),(766,322),(766,333),(765,339),(764,347),
         (708,405),(647,352),(578,364),(498,368),(433,429),(393,489)],-.010,RIM)
    path("Temple rim",[(280,619),(288,553),(320,518),(371,501),
         (348,469),(362,433),(390,405),(372,436),(369,467),(380,505),
         (336,524),(299,563),(280,619)],-.010,RIM)
    eyes=[]
    for name,x,y,rx,rz,angle in (("Left eye",587,687,28,49,.225),("Right eye",758,627,27,49,.18)):
        cx,cz=uv(x,y)
        eye=empty(name+" blink pivot",head,(cx,0,cz))
        feature(name,x,y,rx,rz,-.014,INK,angle,eye)
        eyes.append(eye)
    for name,coords in (("Left brow",[(477,664),(486,624),(529,597),(560,608)]),
                        ("Right brow",[(689,541),(704,501),(748,498),(775,529)])):
        anchor=empty(name+" expression pivot",head)
        flat_line(name,bezier([uv(*p) for p in coords]),.010,-.015,INK,anchor)
        if name=="Right brow":
            brow=anchor
    mouth=empty("Mouth expression",head)
    smile=flat_line("Curious smile",bezier([uv(*p) for p in [(651,766),(678,782),(719,768),(733,734)]]),
                    .010,-.014,INK,mouth)
    puzzled=flat_line("Puzzled closed mouth",bezier([uv(*p) for p in [(654,764),(676,757),(704,756),(723,761)]]),
                      .009,-.014,INK,mouth)
    surprised=oval(
        "Small open mouth",*uv(681,805),.038,.049,-.015,INK,mouth,-.12)
    surprised.hide_render=True
    return head,eyes,brow,(smile,puzzled,surprised)


def shadow_material():
    m=material("Shoe contact • soft radial shadow","172931",ink=1)
    n,l=m.node_tree.nodes,m.node_tree.links
    t=n.new("ShaderNodeTexCoord")
    dist=n.new("ShaderNodeVectorMath")
    dist.operation="DISTANCE"
    dist.inputs[1].default_value=(.5,.5,0)
    l.new(t.outputs["Generated"],dist.inputs[0])
    r=n.new("ShaderNodeMapRange")
    r.clamp=True
    r.interpolation_type="SMOOTHERSTEP"
    r.inputs["From Min"].default_value=.04
    r.inputs["From Max"].default_value=.53
    r.inputs["To Min"].default_value=.55
    r.inputs["To Max"].default_value=0
    l.new(dist.outputs["Value"],r.inputs[0])
    mix=n.new("ShaderNodeMixShader")
    l.new(n.new("ShaderNodeBsdfTransparent").outputs[0],mix.inputs[1])
    l.new(n.get("Emission").outputs[0],mix.inputs[2])
    l.new(r.outputs[0],mix.inputs[0])
    l.new(mix.outputs[0],n.get("Material Output").inputs[0])
    return m


CONTACT=shadow_material()
def flat_limb(name, thickness, y, parent):
    return flat_line(name, [(0,0),(0,1)],thickness,y,INK,parent)


def limb_pose(obj, a, b, frame):
    distance=Vector((b[0]-a[0],0,b[1]-a[1]))
    obj.rotation_euler.y=math.atan2(distance.x,distance.z)
    obj.scale.z=distance.length
    obj.location.x,obj.location.z=a
    for prop in ("location","rotation_euler","scale"):
        obj.keyframe_insert(prop,frame=frame)


def glove(name,parent):
    g=empty(name,parent)
    oval("Outlined flat hand",0,0,.075,.066,-.043,INK,g,-.2)
    oval("Ivory palm",0,0,.059,.052,-.044,FACE,g,-.2)
    flat_line("Mitten thumb crease",[(.017,.008),(.035,-.010)],.006,-.045,INK,g)
    return g


def character(parent, pos, name, poses, indoors=False, frames=None, grips=None):
    root=empty(name,parent,pos)
    feet=[]
    for x,sign in ((-.17,-1),(.18,1)):
        w,d=.39,.30
        mesh("Soft shoe contact", [(-w/2,-d/2,0),(w/2,-d/2,0),(w/2,d/2,0),(-w/2,d/2,0)],
             [(0,1,2,3)],CONTACT,root,(x,.042,.007))
        # The ankle is defined in the same local space as the shoe and its toe.
        toe=empty("Shoe toe pivot",root,(x+sign*.13,0,0))
        shoe_x=-sign*.13
        xy("Flat dark deck shoe",[(shoe_x-.13,0),(shoe_x+.13,0),(shoe_x+.119,.051),
                                  (shoe_x+sign*.043,.104),(shoe_x-sign*.047,.094),
                                  (shoe_x-.118,.074)],-.022,INK,toe)
        flat_line("Shoe upper glint",[(shoe_x-.067,.059),(shoe_x+.030,.068)],
                  .009,-.024,HAIR,toe)
        ankle=empty("Ankle seated inside shoe",toe,(shoe_x,0,.062))
        thigh=flat_limb("Navy trouser leg",.035,-.022,root)
        shin=flat_limb("Navy ankle",.034,-.022,root)
        feet.append((sign,toe,ankle,thigh,shin))
    if not indoors and frames is None:
        # Roll the free heel up over its planted toe while the other shoe stays flat.
        free_toe=feet[0][1]
        for frame,angle in ((1,0),(111,0),(128,-.13),(143,-.17),(159,0),(450,0)):
            free_toe.rotation_euler.y=angle
            free_toe.keyframe_insert("rotation_euler",frame=frame)
    chest=empty("Weight shift over locked soles",root,(0,0,.88))
    jacket=[(-.26,-.28),(-.277,.13),(-.194,.285),(-.084,.316),(0,.244),
            (.088,.316),(.201,.276),(.257,.132),(.245,-.28),(.155,-.329),(-.149,-.329)]
    xy("Outlining around life jacket",jacket,-.02,INK,chest)
    xy("Navy base layer",[(-.233,-.27),(-.25,.126),(-.182,.26),(-.081,.293),
       (0,.211),(.079,.293),(.18,.251),(.234,.126),(.223,-.26),(.14,-.306),(-.13,-.306)],
       -.023,NAVY,chest)
    for sign in (-1,1):
        pts=[(.05,-.265),(.06,.145),(.097,.278),(.176,.254),(.226,.136),(.215,-.261),(.15,-.284)]
        xy("Orange flotation panel",[(sign*x,z) for x,z in pts],-.026,
           ORANGE if sign<0 else ORANGE_SHADE,chest)
        xy("Reflective shoulder tab",[(sign*x,z) for x,z in [(.092,.163),(.184,.142),(.180,.192),(.11,.220)]],
           -.029,REFLECT,chest)
    xy("Harness webbing",[(-.222,-.12),(.23,-.12),(.228,-.18),(-.22,-.18)],-.030,NAVY,chest)
    xy("Harness buckle",[(-.056,-.12),(.05,-.12),(.05,-.18),(-.056,-.18)],-.032,REFLECT,chest)
    xy("Buckle inset",[(-.038,-.134),(.031,-.134),(.031,-.166),(-.038,-.166)],-.033,INK,chest)
    oval("Neck outline",0,.301,.102,.118,-.009,INK,chest)
    oval("Ivory neck",0,.307,.079,.092,-.010,FACE,chest)
    head,eyes,brow,mouths=head_rig(chest)
    head.location=(.01,-.01,.375)
    arms=[(flat_limb("Flat upper sleeve",.030,-.014,root),flat_limb("Flat forearm",.024,-.019,root),glove("Hand",root))
          for _ in range(2)]
    mouths[1].hide_render=True
    if indoors and frames is None:
        for f,active in ((262,0),(283,1),(345,2),(387,0)):
            for index,expression in enumerate(mouths):
                expression.hide_render=index != active
                expression.keyframe_insert("hide_render",frame=f)
        for f,dx,dz in ((262,.010,0),(289,.053,-.037),(337,.069,-.044),
                        (355,.067,-.036),(373,.063,-.033),(389,-.015,.004),
                        (414,-.012,.003),(450,-.012,.003)):
            for eye,(x,y) in zip(eyes,((587,687),(758,627))):
                eye.location.x=(x-621)*.00137+dx
                eye.location.z=(907-y)*.00137+dz
                eye.keyframe_insert("location",frame=f)
    elif frames is None:
        # Sample the contact interval at each output frame so the glove follows
        # the same fixed point on the rim throughout the turn.
        contact=[]
        for left, right in zip(poses, poses[1:]):
            if 105 <= left[0] < 151:
                for frame in range(left[0],right[0]):
                    t=(frame-left[0])/(right[0]-left[0])
                    t=t*t*(3-2*t)
                    contact.append((frame,*(a+(b-a)*t for a,b in zip(left[1:],right[1:]))))
        poses=[pose for pose in poses if not 105 <= pose[0] < 151]+contact
    for f,shift,lean,turn,glance,lift in poses:
        chest.location.x=shift
        chest.location.z=.88+lift
        chest.rotation_euler.y=lean
        chest.keyframe_insert("location",frame=f)
        chest.keyframe_insert("rotation_euler",frame=f)
        head.rotation_euler.y=turn
        head.rotation_euler.z=glance
        head.keyframe_insert("rotation_euler",frame=f)
        for j,sign in enumerate((-1,1)):
            upper,fore,g=arms[j]
            a=(sign*.21+shift,1.05+lift)
            if grips is not None:
                c=grips(f,j) if callable(grips) else grips[j]
                b=((a[0]+c[0])/2+sign*.075,(a[1]+c[1])/2-.13)
            elif j==1 and not indoors and frames is None:
                if 105 <= f <= 151:
                    angle=3.0-wheel_rotation(f)
                    c=(valve.location.x-pos[0]+.235*math.cos(angle),
                       valve.location.z-pos[2]+.235*math.sin(angle))
                    b=(.30+shift,.72+lift*.4)
                elif f<105:
                    b,c=(.32+shift,.88),(.31+shift,.71)
                else:
                    b,c=(.36+shift,.80),(.44+shift,.55)
            elif j==1 and indoors:
                c=(.35+shift,.75+lift)
                b=(.36+shift,.88+lift)
            else:
                c=(-.245+shift,.69+lift)
                b=(-.33+shift,.83+lift)
            limb_pose(upper,a,b,f)
            limb_pose(fore,b,c,f)
            g.location=(c[0],0,c[1])
            g.keyframe_insert("location",frame=f)
    eye_scales=(
        ((300,1),(302,.10),(304,1),(338,1),(349,1.26),(372,1.24),
         (380,.12),(383,1),(450,1)) if indoors else
        ((94,1),(96,.10),(98,1),(228,1),(230,.10),(232,1))
    )
    for f,scale in eye_scales:
        for eye in eyes:
            eye.scale.z=scale
            eye.keyframe_insert("scale",frame=f)
    if indoors:
        for f,amount in ((262,0),(337,0),(352,.090),(372,.087),
                         (389,.053),(413,.073),(450,.065)):
            brow.location.z=amount
            brow.rotation_euler.y=-amount*2.6
            brow.keyframe_insert("location",frame=f)
            brow.keyframe_insert("rotation_euler",frame=f)
    # Bake both segments from a shared knee and the evaluated boot socket.
    # Evaluating the torso and shoe curves first also removes inter-key gaps.
    for f in (frames if frames is not None else (range(262,451) if indoors else range(1,262))):
        scene.frame_set(f)
        for sign,toe,ankle,thigh,shin in feet:
            hip=chest.matrix_basis @ Vector((sign*.126,0,-.284))
            sole=toe.matrix_basis @ ankle.location
            knee=(sign*.173+chest.location.x*.28,
                  .326+(chest.location.z-.88)*.35+sole.z*.12)
            limb_pose(thigh,(hip.x,hip.z),knee,f)
            limb_pose(shin,knee,(sole.x,sole.z),f)
        if frames is not None:
            for sign,(upper,fore,glove_rig) in zip((-1,1),arms):
                shoulder=chest.matrix_basis @ Vector((sign*.205,0,.158))
                elbow=fore.location.copy()
                wrist=glove_rig.location.copy()
                limb_pose(upper,(shoulder.x,shoulder.z),(elbow.x,elbow.z),f)
                limb_pose(fore,(elbow.x,elbow.z),(wrist.x,wrist.z),f)
    return root


character(hull,(13.86,-1.105,1.65),"Oddplot • deck station",[
    (1,-.015,.025,-.12,.10,0),(80,-.02,.038,-.11,.12,.009),
    (92,-.055,-.02,-.085,.24,.005),(105,.015,.065,-.06,.26,-.018),
    (111,-.027,.03,-.095,.25,-.017),(127,.097,.18,.05,.25,-.068),
    (144,.173,.26,.10,.23,-.108),(151,.121,.17,-.04,.14,-.065),
    (165,.006,.028,-.19,.05,.010),
    (210,.013,.029,-.18,.03,0),(261,-.009,-.01,-.19,.03,-.009)], indoors=False)

# Dry cabin is staged as a separated set at X=1000 for accessibility in the edit.
room=empty("Dry forward accommodation • studio section",location=(1000,0,7))
for f in (262,343,450):
    room.rotation_euler.y=hull_pose(f)[0]
    room.keyframe_insert("rotation_euler",frame=f)
box("Cabin floor", (0,0,-.12),(7.0,7.8,.24),FLOOR,room,.06)
for x in (-2.3,-1.15,0,1.15,2.30):
    box("Floor seam",(x,0,.001),(.015,7,.002),DARK,room)
box("Bulkhead lower", (0,1.20,.52),(6.8,.21,1.04),TEAL,room,.045)
box("Bulkhead upper", (0,1.20,2.81),(6.8,.21,.57),WALL,room,.05)
box("Port sill wall", (1.73,1.20,1.77),(3.5,.21,1.56),WALL,room,.04)
box("Port outer wall", (-3.13,1.20,1.77),(.5,.21,1.56),WALL,room,.04)
box("Starboard wall", (-3.39,-.85,1.6),(.20,4.3,3.2),WALL,room,.06)
box("Cabin ceiling", (0,-.34,3.14),(6.8,3.14,.20),WALL,room,.05)
box("Visible ceiling ribs", (0,1.05,3.10),(6.8,.46,.20),TEAL,room,.04)
box("Skirting", (0,1.06,.10),(6.7,.07,.20),DARK,room,.018)
box("Cream trim", (0,1.045,1.01),(6.7,.07,.08),CREAM,room,.015)
window=empty("Actual open window behind steel frame",room,(-1.55,1.075,1.77))
for x in (-1.36,1.36):
    box("Window side jamb", (x,0,0),(.16,.24,1.55),TEAL,window,.04)
for z in (-.73,.73):
    box("Window jamb", (0,0,z),(2.73,.24,.14),TEAL,window,.036)
box("Marine window central mullion", (0,.012,0),(.060,.15,1.43),TEAL,window,.014)
box("Cabin wall panel", (1.89,1.060,1.62),(.89,.14,1.14),TEAL,room,.05)
for z in (1.35,1.66,1.96):
    box("Panel detail", (1.94,.974,z),(.51,.028,.064),STEEL,room,.013)
for x in (-2.70,2.62):
    cylinder("Bulkhead drain run", (x,1.02,.16),(x,1.02,2.95),.046,STEEL,room)
    for z in (.35,1.30,2.27):
        box("Pipe strap",(x,1.019,z),(.17,.075,.055),DARK,room,.016)
for i in range(9):
    x=2.0+i*.119
    box("Upper locker vent", (x,1.057,2.73),(.045,.035,.20),DARK,room,.01)
box("Bunk edge, foreground", (-3.00,-.91,.79),(.56,2.36,.12),TEAL,room,.036)
box("Bunk mattress", (-3.00,-.92,.90),(.52,2.31,.13),CREAM,room,.060)
for x in (-1.55,2.25):
    box("Cable support", (x,1.025,2.64),(.075,.18,.087),STEEL,room,.014)
box("Deck light hood", (.38,.87,2.76),(.52,.22,.15),TEAL,room,.036)
box("Warm lamp diffuser", (.38,.80,2.69),(.44,.15,.06),REFLECT,room,.025)

def rounded_rect(rx,ry,r):
    coords=[]
    for k,(x,y) in enumerate(((rx-r,ry-r),(-rx+r,ry-r),(-rx+r,-ry+r),(rx-r,-ry+r))):
        for i in range(9):
            a=(k+i/8)*math.pi/2
            coords.append((x+math.cos(a)*r,y+math.sin(a)*r))
    return coords


# Opening +Z in the sink's own model. Local wall mount rotates the opening toward
# forward +X, which will become up when FLIP is vertical.
sink=empty("Basin mounted 90° to horizontal deck",room,(.93,.48,1.23))
sink.rotation_euler.y=math.pi/2
loops=[(.37,.29,.112,-.18),(.40,.32,.105,-.10),(.42,.34,.102,-.015),
       (.405,.325,.101,.02),(.345,.267,.078,.02),(.326,.24,.08,-.025),
       (.248,.184,.081,-.101),(.114,.093,.038,-.138)]
count=36
verts=[(x,y,z) for rx,ry,r,z in loops for x,y in rounded_rect(rx,ry,r)]
faces=[(j*count+i,j*count+(i+1)%count,(j+1)*count+(i+1)%count,(j+1)*count+i)
       for j in range(len(loops)-1) for i in range(count)]
faces += [tuple(range((len(loops)-1)*count,len(loops)*count))]
basin=mesh("Deep ceramic basin and rolled inner rim",verts,faces,CERAMIC,sink)
basin.data.materials.append(material("Glazed inner bowl", "A9BEC0", .48, ink=.12))
for p in basin.data.polygons:
    p.use_smooth=True
    if p.index>=count*5:
        p.material_index=1
cylinder("Drain flange in the basin", (0,0,-.139),(0,0,-.129),.076,CHROME,sink,32)
cylinder("Drain grille in the basin", (0,0,-.129),(0,0,-.125),.054,DARK,sink,24)
for i in range(6):
    a=TAU*i/6
    x,y=.032*math.cos(a),.032*math.sin(a)
    cylinder("Drain perforation",(x,y,-.125),(x,y,-.122),.006,CHROME,sink,8)
box("Sink support bolted to former wall", (.714,.77,1.23),(.17,.77,.85),TEAL,room,.052)
pipe("Chrome tap",bezier([(-.27,.22,.010),(-.27,.22,.13),(-.27,.22,.29),(-.19,.20,.25),
                (-.085,.18,.23),(-.101,.113,.215),(-.104,.101,.14)],10),.030,CHROME,sink)
cylinder("Tap escutcheon",(-.27,.22,.01),(-.27,.22,.06),.063,CHROME,sink)
cylinder("Tap lever",(-.285,.22,.14),(-.285,.105,.14),.017,GOLD,sink)
pipe("Trapped drain underneath",[(.72,.45,1.22),(.60,.45,1.22),(.53,.45,1.17),(.53,.45,1.04),
                                (.58,.45,.98),(.65,.50,.96),(.65,1.02,.96)],.042,CHROME,room)
lettering("Engraved orientation label","WASH STATION",(1.54,1.069,.82),.102,REFLECT,room)
practical("Warm window bounce",(998,-.2,10.5),(1000,0,7.7),78,3.8,(1,.86,.69))
practical("Cool off-axis interior fill",(1002,-3.8,9.6),(1000,0,8.2),123,4.0,(.68,.84,1))
practical("Warm lamp pool",(1000.39,.70,9.65),(1000.84,.36,8.20),9,1.25,(1,.76,.48))
practical("Soft ceramic edge light",(1001.75,-1.3,9.05),(1000.52,.46,8.3),29,1.65,(.81,.91,1))
cabin_hero=character(room,(.58,-.38,0),"Oddplot • dry cabin",[
    (262,-.006,.012,-.045,.05,.005),(287,.022,.06,.16,.33,-.010),
    (316,.052,.10,.225,.60,-.023),(337,.058,.105,.24,.61,-.025),
    (351,-.035,-.065,-.10,.56,.047),(371,-.031,-.041,-.084,.54,.028),
    (389,-.017,-.029,-.19,.16,.006),(415,-.024,-.021,-.205,.15,.010),
    (450,-.029,-.027,-.212,.15,.002)],
    indoors=True)
cabin_hero.rotation_euler.z=.91

# Four edit cameras. Their up vector is world +Z, so the sea stays level.
def camera(name):
    d=bpy.data.cameras.new(name)
    d.sensor_fit="VERTICAL"
    d.sensor_height=32
    d.clip_start=.035
    d.clip_end=12000
    obj=bpy.data.objects.new(name,d)
    scene.collection.objects.link(obj)
    return obj


def camera_key(cam, f, eye, target, lens):
    cam.location=eye
    cam.rotation_euler=(Vector(target)-cam.location).to_track_quat("-Z","Y").to_euler()
    cam.data.lens=lens
    cam.keyframe_insert("location",frame=f)
    cam.keyframe_insert("rotation_euler",frame=f)
    cam.data.keyframe_insert("lens",frame=f)


def on_hull(p,f):
    a,z=hull_pose(f)
    x,y,h=p
    return (x*math.cos(a)+h*math.sin(a),y,-x*math.sin(a)+h*math.cos(a)+z)


c1=camera("01 • From spar to the ballast valve")
for data in [
    (1,(-52,-19,6.2),(-73,0,.45),34),
    (18,(-41,-22,7.0),(-65,0,.5),33),
    (36,(-12,-28,8.6),(-38,0,1.0),32),
    (52,(24,-29,9.8),(4.5,-.35,2.65),31),
    (68,(24,-18.0,7.3),(13.0,-.86,2.85),31),
    (84,(17.3,-7.0,4.02),(14.27,-.85,2.67),36),
    (101,(15.90,-5.59,3.26),(14.25,-.94,2.42),39),
    (136,(15.40,-5.18,3.21),(14.27,-.94,2.40),39),
    (165,(15.19,-4.99,3.14),(14.27,-.94,2.39),39),
]:
    f,eye,target,lens=data
    camera_key(c1,f,on_hull(eye,f) if f>66 else eye,on_hull(target,f) if f>66 else target,lens)

c2=camera("02 • Dry bow rises while the spar goes under")
camera_key(c2,166,(21,-36,8.5),(9.0,0,3.5),27)
camera_key(c2,210,(19,-34,8.6),(10.1,0,4.25),27)
camera_key(c2,261,(17,-32,8.7),(11.0,0,5.0),27)

def cabin_camera_key(cam, f, eye, target, lens):
    rotation=Matrix.Rotation(hull_pose(f)[0],3,"Y")
    cam.location=Vector(room.location)+rotation@Vector(eye)
    orientation=(Vector(target)-Vector(eye)).to_track_quat("-Z","Y")
    cam.rotation_euler=(rotation.to_quaternion()@orientation).to_euler()
    cam.data.lens=lens
    cam.keyframe_insert("location",frame=f)
    cam.keyframe_insert("rotation_euler",frame=f)
    cam.data.keyframe_insert("lens",frame=f)


c3=camera("03 • Face of the sideways sink")
cabin_camera_key(c3,262,(4.95,-3.20,2.17),(.67,-.13,1.05),31)
cabin_camera_key(c3,303,(4.67,-2.85,2.12),(.68,-.13,1.13),32)
cabin_camera_key(c3,336,(4.50,-2.58,2.10),(.69,-.13,1.20),32)

c4=camera("04 • Realization and look to camera")
cabin_camera_key(c4,337,(4.28,-2.43,2.09),(.69,-.11,1.20),33)
cabin_camera_key(c4,382,(4.07,-2.25,2.02),(.70,-.10,1.27),33)
cabin_camera_key(c4,450,(3.96,-2.16,1.99),(.70,-.10,1.28),33)
for frame, camera_obj in zip(CUTS,(c1,c2,c3,c4)):
    mark=scene.timeline_markers.new(camera_obj.name,frame=frame)
    mark.camera=camera_obj

# A single picture-in-picture witness beat, drawn independently of the approved crew avatar.
card=empty("Witness phone call • camera-space inset",c1)
card.rotation_euler.x=-math.pi/2
card.scale=(.51,)*3
for f,x,y in ((1,.167,.650),(19,.167,.655),(43,.164,.650),(49,.171,.655),
              (57,2.04,.75),(450,2.04,.75)):
    card.location=(x,y,-2.12)
    card.keyframe_insert("location",frame=f)

card_dark=material("Inset navy edge","101A32",ink=1)
card_bg=material("Inset • harbor fog","628C92",ink=1)
card_sky=material("Inset • mist","AFC5BD",ink=1)
card_jacket=material("Inset • slate pullover","354865",ink=1)
card_skin=material("Inset • warm brown","D59873",ink=1)
card_cap=material("Inset • knit watch cap","783D34",ink=1)
def panel(name, cx,cz,rx,rz,r,y,mat):
    return xy(name,[(x+cx,z+cz) for x,z in rounded_rect(rx,rz,r)],y,mat,card)

panel("Witness inset light border",0,0,.64,.462,.064,0,FACE)
panel("Witness inset mid",0,0,.624,.444,.053,-.002,card_bg)
xy("Distant harbor blue",[(-.58,.38),(.58,.38),(.58,.13),(-.58,.13)],-.004,card_sky,card)
xy("Harbor wall",[(-.58,-.01),(.58,-.01),(.58,-.06),(-.58,-.06)],-.006,TEAL,card)
panel("Witness pull-over",.035,-.244,.355,.162,.113,-.013,INK)
panel("Witness garment",.035,-.251,.334,.146,.106,-.014,card_jacket)
oval("Witness head outline",.05,.056,.222,.254,-.021,INK,card,-.13)
oval("Witness head",.05,.051,.205,.237,-.022,card_skin,card,-.13)
xy("Dark watch cap",bezier([(-.189,.089),(-.196,.282),(-.119,.365),(.036,.363),
                           (.155,.36),(.249,.247),(.254,.125),(.13,.121),(-.058,.106),(-.189,.089)]),
   -.026,INK,card)
xy("Knit watch cap",bezier([(-.174,.115),(-.174,.278),(-.114,.349),(.030,.343),
                           (.153,.338),(.229,.238),(.235,.141),(.12,.133),(-.060,.124),(-.174,.115)]),
   -.027,card_cap,card)
flat_line("Cap cuff",[(-.171,.144),(-.055,.154),(.079,.167),(.222,.178)],.016,-.029,INK,card)
for x,z in ((.026,.046),(.137,.061)):
    oval("Concerned witness eye",x,z,.017,.033,-.029,INK,card,.12)
flat_line("Worry brow",[(-.008,.097),(.017,.108),(.055,.106)],.010,-.031,INK,card)
flat_line("Worry brow",[(.108,.106),(.138,.123),(.173,.117)],.010,-.031,INK,card)
flat_line("Calling expression",[(.059,-.084),(.088,-.065),(.124,-.070)],.011,-.031,INK,card)
panel("Phone by ear",-.201,-.014,.068,.148,.024,-.038,card_dark)
flat_line("Phone screen edge",[(-.216,-.085),(-.217,.060)],.008,-.039,card_bg,card)
oval("Fingers around phone",-.213,-.082,.056,.069,-.041,card_skin,card,-.45)
flat_line("Bent witness arm",[(-.193,-.097),(-.235,-.191),(-.349,-.259)],.020,-.036,INK,card)
for i in range(3):
    x=-.342-i*.033
    flat_line("Call signal",[(x,.146-i*.015),(x-.015,.185),(x,.224+i*.015)],
              .008,-.032,FACE,card)

scene.camera=c1
scene.frame_start,scene.frame_end=1,450
scene.render.fps=FPS
scene.render.resolution_x,scene.render.resolution_y=1080,1920
scene.render.resolution_percentage=100
scene.render.image_settings.file_format="JPEG"
scene.render.image_settings.quality=95
scene.render.filepath="//frames/frame_"
scene.render.film_transparent=False
scene.view_settings.view_transform="Standard"
scene.view_settings.look="None"
scene.view_settings.exposure=-.06
scene.eevee.taa_render_samples=int(os.environ.get("ODDPLOT_EEVEE_SAMPLES", "2"))
scene.eevee.shadow_step_count=4
scene.render.engine="BLENDER_EEVEE_NEXT"
scene.cycles.device="CPU"
scene.cycles.use_denoising=False
scene.cycles.use_adaptive_sampling=False
scene.cycles.samples=int(os.environ.get("ODDPLOT_SAMPLES", "4"))
scene.cycles.max_bounces=1
scene.cycles.diffuse_bounces=0
scene.cycles.glossy_bounces=0
scene.cycles.transparent_max_bounces=4
scene.cycles.use_animated_seed=False
scene.render.use_persistent_data=True
scene.render.threads_mode="FIXED"
scene.render.threads=int(os.environ.get("ODDPLOT_RENDER_THREADS", "4"))
scene["design_source"]="Oddplot_Test_001. Avatar traced from the supplied chat image."
scene["physical_continuity"]="Four cameras. Shoals and horizon use world space. Feet use station coordinates."
scene.frame_set(1)
